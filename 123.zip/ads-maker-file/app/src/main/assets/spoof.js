// ============================================================================
// Advanced Fingerprint Spoofing Script - Synced with MainActivity.java
// ============================================================================
(function () {
  'use strict';

  // ─── Helpers ───────────────────────────────────────────────────────────────
  function getParam(name) {
    var m = location.search.match(new RegExp('[?&]' + name + '=([^&]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }

  function seededRandom(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) {
      h = (h << 5) - h + s.charCodeAt(i);
      h |= 0;
    }
    return function () {
      h = ((h * 9301 + 49297) % 233280);
      return h / 233280;
    };
  }

  function randInt(min, max) { return Math.floor(rng() * (max - min + 1)) + min; }
  function randChoice(arr)   { return arr[randInt(0, arr.length - 1)]; }

  // ─── Bootstrap ────────────────────────────────────────────────────────────
  var seed    = getParam('vid')     || 'defaultseed';
  var country = getParam('country') || 'US';       // injected by MainActivity

  var rng = seededRandom(seed + country);          // country baked into seed

  console.log('[SPOOF] Starting – seed:', seed.substring(0, 8), '| country:', country);

  // ═══════════════════════════════════════════════════════════════════════════
  // 1. LANGUAGE & LOCALE  (matches MainActivity COUNTRY_LANGUAGE_MAP)
  // ═══════════════════════════════════════════════════════════════════════════
  var COUNTRY_LANGUAGE_MAP = {
    US: 'en-US,en;q=0.9',
    GB: 'en-GB,en;q=0.9',
    DE: 'de-DE,de;q=0.9,en;q=0.8',
    FR: 'fr-FR,fr;q=0.9,en;q=0.8',
    SG: 'en-SG,en;q=0.9,zh-SG;q=0.8',
    JP: 'ja-JP,ja;q=0.9,en;q=0.8',
    CA: 'en-CA,en;q=0.9,fr-CA;q=0.8',
    AU: 'en-AU,en;q=0.9',
    NL: 'nl-NL,nl;q=0.9,en;q=0.8',
    BR: 'pt-BR,pt;q=0.9,en;q=0.8',
    KR: 'ko-KR,ko;q=0.9,en;q=0.8',
    PL: 'pl-PL,pl;q=0.9,en;q=0.8',
    MX: 'es-MX,es;q=0.9,en;q=0.8',
    AE: 'ar-AE,ar;q=0.9,en;q=0.8',
    IT: 'it-IT,it;q=0.9,en;q=0.8'
  };

  var COUNTRY_REFERER_MAP = {
    US: ['https://www.google.com/',    'https://www.bing.com/',       'https://www.reddit.com/'],
    GB: ['https://www.google.co.uk/',  'https://www.bbc.co.uk/',      'https://www.reddit.com/'],
    DE: ['https://www.google.de/',     'https://www.bing.com/',       'https://www.t-online.de/'],
    FR: ['https://www.google.fr/',     'https://www.bing.com/',       'https://www.lefigaro.fr/'],
    SG: ['https://www.google.com.sg/', 'https://www.bing.com/',       'https://www.straitstimes.com/'],
    JP: ['https://www.google.co.jp/',  'https://www.yahoo.co.jp/',    'https://www.bing.com/'],
    CA: ['https://www.google.ca/',     'https://www.bing.com/',       'https://www.reddit.com/'],
    AU: ['https://www.google.com.au/', 'https://www.bing.com/',       'https://www.reddit.com/'],
    NL: ['https://www.google.nl/',     'https://www.bing.com/',       'https://www.nu.nl/'],
    BR: ['https://www.google.com.br/', 'https://www.bing.com/',       'https://www.globo.com/'],
    KR: ['https://www.google.co.kr/',  'https://www.naver.com/',      'https://www.bing.com/'],
    PL: ['https://www.google.pl/',     'https://www.bing.com/',       'https://www.onet.pl/'],
    MX: ['https://www.google.com.mx/', 'https://www.bing.com/',       'https://www.reddit.com/'],
    AE: ['https://www.google.ae/',     'https://www.bing.com/',       'https://www.reddit.com/'],
    IT: ['https://www.google.it/',     'https://www.bing.com/',       'https://www.corriere.it/']
  };

  var langString  = COUNTRY_LANGUAGE_MAP[country] || 'en-US,en;q=0.9';
  var primaryLang = langString.split(',')[0].split(';')[0].trim();    // e.g. "en-US"
  var langList    = langString.split(',').map(function (l) {
    return l.split(';')[0].trim();
  });
  var referers    = COUNTRY_REFERER_MAP[country] || ['https://www.google.com/'];
  var referer     = randChoice(referers);

  try {
    Object.defineProperty(navigator, 'language',  { get: function () { return primaryLang; }, configurable: true });
    Object.defineProperty(navigator, 'languages', { get: function () { return langList;    }, configurable: true });
    Object.defineProperty(document,  'referrer',  { get: function () { return referer;     }, configurable: true });
    console.log('[SPOOF] Lang:', primaryLang, '| Referer:', referer);
  } catch (e) {
    console.log('[SPOOF] Lang/referrer error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 2. TIMEZONE  (matches MainActivity getCountryTimezoneOffset)
  // ═══════════════════════════════════════════════════════════════════════════
  var COUNTRY_TZ_OFFSET = {
    US:  300,   // UTC-5
    GB:  0,     // UTC+0
    DE: -60,    // UTC+1
    FR: -60,
    IT: -60,
    NL: -60,
    PL: -60,
    SG: -480,   // UTC+8
    JP: -540,   // UTC+9
    KR: -540,
    CA:  300,   // UTC-5
    AU: -600,   // UTC+10
    BR:  180,   // UTC-3
    MX:  360,   // UTC-6
    AE: -240    // UTC+4
  };

  var tzOffset = (COUNTRY_TZ_OFFSET[country] !== undefined)
      ? COUNTRY_TZ_OFFSET[country]
      : 0;

  try {
    Date.prototype.getTimezoneOffset = function () { return tzOffset; };

    // Also spoof Intl.DateTimeFormat so advanced detection is blocked
    var origDTF = Intl.DateTimeFormat;
    Intl.DateTimeFormat = function (locale, opts) {
      opts = opts || {};
      if (!opts.timeZone) opts.timeZone = tzOffsetToIANA(country);
      return new origDTF(locale, opts);
    };
    Intl.DateTimeFormat.prototype          = origDTF.prototype;
    Intl.DateTimeFormat.supportedLocalesOf = origDTF.supportedLocalesOf;

    console.log('[SPOOF] TZ offset:', tzOffset, '| IANA:', tzOffsetToIANA(country));
  } catch (e) {
    console.log('[SPOOF] Timezone error:', e.message);
  }

  function tzOffsetToIANA(c) {
    var map = {
      US: 'America/New_York', GB: 'Europe/London',  DE: 'Europe/Berlin',
      FR: 'Europe/Paris',     IT: 'Europe/Rome',    NL: 'Europe/Amsterdam',
      PL: 'Europe/Warsaw',    SG: 'Asia/Singapore', JP: 'Asia/Tokyo',
      KR: 'Asia/Seoul',       CA: 'America/Toronto',AU: 'Australia/Sydney',
      BR: 'America/Sao_Paulo',MX: 'America/Mexico_City', AE: 'Asia/Dubai'
    };
    return map[c] || 'UTC';
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 3. SCREEN DIMENSIONS  (realistic mobile resolutions)
  // ═══════════════════════════════════════════════════════════════════════════
  var screenConfigs = [
    {w:360,  h:640,  dpr:2},
    {w:360,  h:800,  dpr:3},
    {w:375,  h:667,  dpr:2},
    {w:390,  h:844,  dpr:3},
    {w:393,  h:851,  dpr:2.625},
    {w:412,  h:915,  dpr:2.625},
    {w:414,  h:896,  dpr:3},
    {w:428,  h:926,  dpr:3},
    {w:360,  h:780,  dpr:3},
    {w:384,  h:854,  dpr:2.5},
    {w:411,  h:731,  dpr:2.6},
    {w:432,  h:960,  dpr:3}
  ];
  var cfg      = randChoice(screenConfigs);
  var screenW  = cfg.w;
  var screenH  = cfg.h;
  var dpr      = cfg.dpr;
  var colorDepth = randChoice([24, 32]);
  // innerHeight leaves room for browser chrome
  var innerH   = screenH - randInt(50, 120);
  var availH   = screenH - randInt(0, 24);

  try {
    Object.defineProperty(screen, 'width',       { get: function () { return screenW;    }, configurable: true });
    Object.defineProperty(screen, 'height',      { get: function () { return screenH;    }, configurable: true });
    Object.defineProperty(screen, 'availWidth',  { get: function () { return screenW;    }, configurable: true });
    Object.defineProperty(screen, 'availHeight', { get: function () { return availH;     }, configurable: true });
    Object.defineProperty(screen, 'colorDepth',  { get: function () { return colorDepth; }, configurable: true });
    Object.defineProperty(screen, 'pixelDepth',  { get: function () { return colorDepth; }, configurable: true });
    Object.defineProperty(window, 'devicePixelRatio', { get: function () { return dpr;      }, configurable: true });
    Object.defineProperty(window, 'innerWidth',  { get: function () { return screenW;    }, configurable: true });
    Object.defineProperty(window, 'innerHeight', { get: function () { return innerH;     }, configurable: true });
    Object.defineProperty(window, 'outerWidth',  { get: function () { return screenW;    }, configurable: true });
    Object.defineProperty(window, 'outerHeight', { get: function () { return screenH;    }, configurable: true });
    console.log('[SPOOF] Screen:', screenW + 'x' + screenH, '| DPR:', dpr);
  } catch (e) {
    console.log('[SPOOF] Screen error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 4. NAVIGATOR HARDWARE PROPERTIES
  // ═══════════════════════════════════════════════════════════════════════════
  var hardwareConcurrency = randChoice([4, 6, 8, 10, 12]);
  var deviceMemory        = randChoice([2, 3, 4, 6, 8]);
  var maxTouchPoints      = randChoice([1, 5, 10]);
  var platform            = randChoice(['Linux armv81', 'Linux armv8l', 'Linux aarch64', 'Android']);

  try {
    Object.defineProperty(navigator, 'hardwareConcurrency', { get: function () { return hardwareConcurrency; }, configurable: true });
    Object.defineProperty(navigator, 'deviceMemory',        { get: function () { return deviceMemory;        }, configurable: true });
    Object.defineProperty(navigator, 'maxTouchPoints',      { get: function () { return maxTouchPoints;      }, configurable: true });
    Object.defineProperty(navigator, 'platform',            { get: function () { return platform;            }, configurable: true });
    // Block automation detection
    Object.defineProperty(navigator, 'webdriver',           { get: function () { return false;               }, configurable: true });
    console.log('[SPOOF] HW:', hardwareConcurrency, 'cores |', deviceMemory, 'GB | touches:', maxTouchPoints);
  } catch (e) {
    console.log('[SPOOF] Navigator error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 5. WEBGL FINGERPRINT
  // ═══════════════════════════════════════════════════════════════════════════
  // Vendor/renderer pairs kept realistic for Android mobile GPUs
  var glProfiles = [
    { vendor: 'Qualcomm',                      renderer: 'Adreno (TM) 730'                              },
    { vendor: 'Qualcomm',                      renderer: 'Adreno (TM) 660'                              },
    { vendor: 'Qualcomm',                      renderer: 'Adreno (TM) 640'                              },
    { vendor: 'Qualcomm',                      renderer: 'Adreno (TM) 619'                              },
    { vendor: 'ARM',                           renderer: 'Mali-G78'                                     },
    { vendor: 'ARM',                           renderer: 'Mali-G77'                                     },
    { vendor: 'ARM',                           renderer: 'Mali-G710'                                    },
    { vendor: 'Google Inc. (Qualcomm)',        renderer: 'ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)' },
    { vendor: 'Google Inc. (ARM)',             renderer: 'ANGLE (ARM, Mali-G78, OpenGL ES 3.2)'         },
    { vendor: 'Imagination Technologies',     renderer: 'PowerVR Rogue GE8320'                        },
    { vendor: 'Apple Inc.',                    renderer: 'Apple A15 GPU'                                },
    { vendor: 'Apple Inc.',                    renderer: 'Apple A16 GPU'                                }
  ];

  var glProfile   = randChoice(glProfiles);
  var glVendor    = glProfile.vendor;
  var glRenderer  = glProfile.renderer;

  function patchWebGL(ctx) {
    if (!ctx || !ctx.prototype) return;
    var orig = ctx.prototype.getParameter;
    ctx.prototype.getParameter = function (param) {
      if (param === 37445) return glVendor;   // UNMASKED_VENDOR_WEBGL
      if (param === 37446) return glRenderer; // UNMASKED_RENDERER_WEBGL
      return orig.call(this, param);
    };
  }

  try {
    patchWebGL(WebGLRenderingContext);
    if (typeof WebGL2RenderingContext !== 'undefined') patchWebGL(WebGL2RenderingContext);
    console.log('[SPOOF] WebGL:', glVendor, '/', glRenderer);
  } catch (e) {
    console.log('[SPOOF] WebGL error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 6. CANVAS FINGERPRINT NOISE
  // ═══════════════════════════════════════════════════════════════════════════
  // Noise is seeded so it is consistent within a session but unique per vid/country
  var noiseR = Math.round((rng() * 4) - 2);  // -2 … +2  integer per channel
  var noiseG = Math.round((rng() * 4) - 2);
  var noiseB = Math.round((rng() * 4) - 2);

  function clamp(v) { return Math.min(255, Math.max(0, v)); }

  try {
    var origToDataURL  = HTMLCanvasElement.prototype.toDataURL;
    var origToBlob     = HTMLCanvasElement.prototype.toBlob;
    var origGetContext = HTMLCanvasElement.prototype.getContext;

    function addCanvasNoise(canvas) {
      try {
        var ctx2d = origGetContext.call(canvas, '2d');
        if (!ctx2d || canvas.width === 0 || canvas.height === 0) return;
        var imgData = ctx2d.getImageData(0, 0, canvas.width, canvas.height);
        var d = imgData.data;
        // Only touch first 100 pixels to minimise visual impact
        for (var i = 0; i < Math.min(d.length, 400); i += 4) {
          d[i]     = clamp(d[i]     + noiseR);
          d[i + 1] = clamp(d[i + 1] + noiseG);
          d[i + 2] = clamp(d[i + 2] + noiseB);
          // alpha untouched
        }
        ctx2d.putImageData(imgData, 0, 0);
      } catch (_) {}
    }

    HTMLCanvasElement.prototype.toDataURL = function () {
      addCanvasNoise(this);
      return origToDataURL.apply(this, arguments);
    };

    HTMLCanvasElement.prototype.toBlob = function (cb) {
      addCanvasNoise(this);
      return origToBlob.apply(this, arguments);
    };

    console.log('[SPOOF] Canvas noise R:', noiseR, 'G:', noiseG, 'B:', noiseB);
  } catch (e) {
    console.log('[SPOOF] Canvas error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 7. AUDIO FINGERPRINT NOISE
  // ═══════════════════════════════════════════════════════════════════════════
  try {
    var AudioContext = window.AudioContext || window.webkitAudioContext;
    if (AudioContext) {
      var origCreateAnalyser   = AudioContext.prototype.createAnalyser;
      var origCreateOscillator = AudioContext.prototype.createOscillator;
      var audioNoise = (rng() * 0.0002) - 0.0001; // tiny float offset

      AudioContext.prototype.createAnalyser = function () {
        var node = origCreateAnalyser.apply(this, arguments);
        var origGetFloatFreq = node.getFloatFrequencyData.bind(node);
        node.getFloatFrequencyData = function (arr) {
          origGetFloatFreq(arr);
          for (var i = 0; i < arr.length; i++) arr[i] += audioNoise;
        };
        return node;
      };
      console.log('[SPOOF] Audio noise:', audioNoise.toFixed(6));
    }
  } catch (e) {
    console.log('[SPOOF] Audio error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 8. NETWORK INFORMATION API
  // ═══════════════════════════════════════════════════════════════════════════
  try {
    var connectionTypes = [
      { effectiveType: '4g', downlink: 10.5, rtt: 65  },
      { effectiveType: '4g', downlink: 8.2,  rtt: 80  },
      { effectiveType: '4g', downlink: 15.0, rtt: 50  },
      { effectiveType: '3g', downlink: 1.5,  rtt: 200 },
      { effectiveType: '4g', downlink: 20.0, rtt: 40  }
    ];
    var connProfile = randChoice(connectionTypes);

    if (navigator.connection) {
      Object.defineProperty(navigator.connection, 'effectiveType',
          { get: function () { return connProfile.effectiveType; }, configurable: true });
      Object.defineProperty(navigator.connection, 'downlink',
          { get: function () { return connProfile.downlink;      }, configurable: true });
      Object.defineProperty(navigator.connection, 'rtt',
          { get: function () { return connProfile.rtt;           }, configurable: true });
      Object.defineProperty(navigator.connection, 'saveData',
          { get: function () { return false;                     }, configurable: true });
      console.log('[SPOOF] Connection:', connProfile.effectiveType, connProfile.downlink, 'Mbps');
    }
  } catch (e) {
    console.log('[SPOOF] Connection error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 9. BATTERY API  (static plausible values)
  // ═══════════════════════════════════════════════════════════════════════════
  try {
    if (navigator.getBattery) {
      var batteryLevel = 0.4 + rng() * 0.55;   // 40 – 95 %
      var charging     = rng() > 0.5;

      navigator.getBattery = function () {
        return Promise.resolve({
          charging:        charging,
          chargingTime:    charging ? Math.round(rng() * 3600) : Infinity,
          dischargingTime: charging ? Infinity : Math.round(3600 + rng() * 14400),
          level:           parseFloat(batteryLevel.toFixed(2)),
          addEventListener:    function () {},
          removeEventListener: function () {}
        });
      };
      console.log('[SPOOF] Battery:', (batteryLevel * 100).toFixed(0) + '%', charging ? '(charging)' : '(discharging)');
    }
  } catch (e) {
    console.log('[SPOOF] Battery error:', e.message);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // 10. PERMISSION API  (always return 'granted' / 'prompt', never 'denied')
  // ═══════════════════════════════════════════════════════════════════════════
  try {
    if (navigator.permissions && navigator.permissions.query) {
      var origQuery = navigator.permissions.query.bind(navigator.permissions);
      navigator.permissions.query = function (desc) {
        return origQuery(desc).then(function (result) {
          Object.defineProperty(result, 'state',
              { get: function () { return 'granted'; }, configurable: true });
          return result;
        }).catch(function () {
          return { state: 'granted' };
        });
      };
      console.log('[SPOOF] Permissions API patched');
    }
  } catch (e) {
    console.log('[SPOOF] Permissions error:', e.message);
  }

  // ─── Done ─────────────────────────────────────────────────────────────────
  console.log('[SPOOF] ✓ All spoofs applied | country=' + country
      + ' | seed=' + seed.substring(0, 8));

})();