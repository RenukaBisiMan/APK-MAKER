package com.adsviewer.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import com.wireguard.config.Interface;
import com.wireguard.config.Peer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AdsViewer";
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String currentLanguage = "en-US,en;q=0.9";
    private String currentReferer = "https://www.google.com/";
    private int rotationCount = 0;
    private String currentExitIp = "unknown";
    private String currentCountry = "US";

    // WARP / WireGuard state
    private Backend wgBackend;
    private final WarpTunnel warpTunnel = new WarpTunnel();
    private boolean warpUp = false;
    private static final int REREGISTER_EVERY_N_ROTATIONS = 5;
    private int rotationsSinceReregister = 0;
    private int countryRotationIndex = 0;

    private ActivityResultLauncher<Intent> vpnPermissionLauncher;

    // ─── Geo-rotation: Cloudflare WARP endpoints per region ──────────────────
    // WARP always exits through Cloudflare's nearest PoP for that endpoint region.
    // Endpoints are Cloudflare's published anycast WireGuard entry points.
    // We deliberately exclude India (IN) from this list.
    private static final GeoEndpoint[] GEO_ENDPOINTS = new GeoEndpoint[]{
        // United States
        new GeoEndpoint("US", "engage.cloudflareclient.com:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // United Kingdom
        new GeoEndpoint("GB", "162.159.192.1:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Germany
        new GeoEndpoint("DE", "162.159.193.1:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // France
        new GeoEndpoint("FR", "162.159.195.1:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Singapore
        new GeoEndpoint("SG", "162.159.192.5:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Japan
        new GeoEndpoint("JP", "162.159.193.5:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Canada
        new GeoEndpoint("CA", "162.159.195.5:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Australia
        new GeoEndpoint("AU", "162.159.192.9:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Netherlands
        new GeoEndpoint("NL", "162.159.193.9:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Brazil
        new GeoEndpoint("BR", "162.159.195.9:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // South Korea
        new GeoEndpoint("KR", "162.159.192.13:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Poland
        new GeoEndpoint("PL", "162.159.193.13:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Mexico
        new GeoEndpoint("MX", "162.159.195.13:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // UAE
        new GeoEndpoint("AE", "162.159.192.17:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
        // Italy
        new GeoEndpoint("IT", "162.159.193.17:2408",
                "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU="),
    };

    // ─── Language map per country ─────────────────────────────────────────────
    private static final Map<String, String> COUNTRY_LANGUAGE_MAP = new HashMap<String, String>() {{
        put("US", "en-US,en;q=0.9");
        put("GB", "en-GB,en;q=0.9");
        put("DE", "de-DE,de;q=0.9,en;q=0.8");
        put("FR", "fr-FR,fr;q=0.9,en;q=0.8");
        put("SG", "en-SG,en;q=0.9,zh-SG;q=0.8");
        put("JP", "ja-JP,ja;q=0.9,en;q=0.8");
        put("CA", "en-CA,en;q=0.9,fr-CA;q=0.8");
        put("AU", "en-AU,en;q=0.9");
        put("NL", "nl-NL,nl;q=0.9,en;q=0.8");
        put("BR", "pt-BR,pt;q=0.9,en;q=0.8");
        put("KR", "ko-KR,ko;q=0.9,en;q=0.8");
        put("PL", "pl-PL,pl;q=0.9,en;q=0.8");
        put("MX", "es-MX,es;q=0.9,en;q=0.8");
        put("AE", "ar-AE,ar;q=0.9,en;q=0.8");
        put("IT", "it-IT,it;q=0.9,en;q=0.8");
    }};

    // ─── Referer map per country ──────────────────────────────────────────────
    private static final Map<String, String[]> COUNTRY_REFERER_MAP = new HashMap<String, String[]>() {{
        put("US", new String[]{"https://www.google.com/", "https://www.bing.com/", "https://www.reddit.com/"});
        put("GB", new String[]{"https://www.google.co.uk/", "https://www.bbc.co.uk/", "https://www.reddit.com/"});
        put("DE", new String[]{"https://www.google.de/", "https://www.bing.com/", "https://www.t-online.de/"});
        put("FR", new String[]{"https://www.google.fr/", "https://www.bing.com/", "https://www.lefigaro.fr/"});
        put("SG", new String[]{"https://www.google.com.sg/", "https://www.bing.com/", "https://www.straitstimes.com/"});
        put("JP", new String[]{"https://www.google.co.jp/", "https://www.yahoo.co.jp/", "https://www.bing.com/"});
        put("CA", new String[]{"https://www.google.ca/", "https://www.bing.com/", "https://www.reddit.com/"});
        put("AU", new String[]{"https://www.google.com.au/", "https://www.bing.com/", "https://www.reddit.com/"});
        put("NL", new String[]{"https://www.google.nl/", "https://www.bing.com/", "https://www.nu.nl/"});
        put("BR", new String[]{"https://www.google.com.br/", "https://www.bing.com/", "https://www.globo.com/"});
        put("KR", new String[]{"https://www.google.co.kr/", "https://www.naver.com/", "https://www.bing.com/"});
        put("PL", new String[]{"https://www.google.pl/", "https://www.bing.com/", "https://www.onet.pl/"});
        put("MX", new String[]{"https://www.google.com.mx/", "https://www.bing.com/", "https://www.reddit.com/"});
        put("AE", new String[]{"https://www.google.ae/", "https://www.bing.com/", "https://www.reddit.com/"});
        put("IT", new String[]{"https://www.google.it/", "https://www.bing.com/", "https://www.corriere.it/"});
    }};

    private static final String[] DEVICE_MODELS = new String[]{
        "SM-S908B", "SM-S918B", "SM-A546B", "SM-G998U", "SM-N986U", "SM-F946B", "SM-A536E",
        "Pixel 6", "Pixel 6 Pro", "Pixel 7", "Pixel 7 Pro", "Pixel 8", "Pixel 8 Pro", "Pixel 9", "Pixel 9 Pro",
        "Redmi Note 12", "Redmi Note 13", "Redmi Note 11", "M2102J20SG", "M2103K19PG", "23021RAA2Y",
        "OnePlus 11", "OnePlus 12", "OnePlus 9 Pro", "PJF110", "CPH2581",
        "Nokia G50", "Nokia X20", "TA-1456",
        "moto g stylus 5G", "motorola edge 40", "XT2255-1",
        "ASUS_AI2202", "ASUS_I003D",
        "vivo X100", "V2309", "V2241A",
        "POCO X6 Pro", "POCO F5", "23076PC4BG",
        "realme GT 5", "RMX3700",
        "Honor Magic5", "PGT-N19",
        "Infinix HOT 30", "Infinix X6831"
    };

    // ─── GeoEndpoint descriptor ───────────────────────────────────────────────
    private static class GeoEndpoint {
        final String countryCode;
        final String endpoint;
        final String serverPublicKey;

        GeoEndpoint(String countryCode, String endpoint, String serverPublicKey) {
            this.countryCode = countryCode;
            this.endpoint = endpoint;
            this.serverPublicKey = serverPublicKey;
        }
    }

    /** Tunnel descriptor required by GoBackend. */
    private static class WarpTunnel implements Tunnel {
        @Override
        public String getName() { return "warp"; }

        @Override
        public void onStateChange(State newState) {
            Log.d(TAG, "[WARP] Tunnel state: " + newState);
        }
    }

    // ─── JavaScript Bridge ────────────────────────────────────────────────────
    public class AdCounterBridge {
        @JavascriptInterface
        public int getAdLoadCount() {
            return prefs.getInt("adLoadCount", 0);
        }

        @JavascriptInterface
        public void setAdLoadCount(int count) {
            prefs.edit().putInt("adLoadCount", count).apply();
            Log.d(TAG, "[BRIDGE] Saved ad count: " + count);

            // Rotate WARP identity every 500 ads
            if (count > 0 && count % 500 == 0) {
                Log.d(TAG, "[WARP] Ad load count reached " + count + ", triggering IP rotation");
                handler.post(() -> rotateWarpIdentity());
            }
        }

        @JavascriptInterface
        public String getCurrentCountry() {
            return currentCountry;
        }

        @JavascriptInterface
        public String getCurrentIp() {
            return currentExitIp;
        }
    }

    // ─── User-Agent helpers ───────────────────────────────────────────────────
    private String randomBuildId() {
        char[] prefixOptions = {'U', 'T', 'S', 'R', 'Q', 'P'};
        char p = prefixOptions[random.nextInt(prefixOptions.length)];
        int year = 22 + random.nextInt(4);
        int month = 1 + random.nextInt(12);
        int day = 1 + random.nextInt(28);
        int patch = random.nextInt(40);
        return String.format("%cP%dA.%02d%02d%02d.%03d",
                p, 1 + random.nextInt(2), year, month, day, patch);
    }

    private String randomUserAgent() {
        int kind = random.nextInt(10);
        if (kind == 0) {
            // iOS Chrome UA
            int iosMajor = 14 + random.nextInt(5);
            int iosMinor = random.nextInt(7);
            int chromeMajor = 110 + random.nextInt(25);
            int chromeMinor = random.nextInt(7000);
            int chromePatch = random.nextInt(250);
            return "Mozilla/5.0 (iPhone; CPU iPhone OS " + iosMajor + "_" + iosMinor
                    + " like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/"
                    + chromeMajor + ".0." + chromeMinor + "." + chromePatch
                    + " Mobile/15E148 Safari/604.1";
        }
        // Android Chrome UA
        int androidMajor = 9 + random.nextInt(7);
        int chromeMajor = 100 + random.nextInt(35);
        int chromeBuild = 1000 + random.nextInt(7500);
        int chromePatch = random.nextInt(250);
        String model = DEVICE_MODELS[random.nextInt(DEVICE_MODELS.length)];
        String build = (random.nextInt(2) == 0) ? "" : " Build/" + randomBuildId();
        if (random.nextInt(3) == 0) {
            model = model + "-" + (char) ('A' + random.nextInt(26)) + (100 + random.nextInt(900));
        }
        return "Mozilla/5.0 (Linux; Android " + androidMajor + "; " + model + build
                + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + chromeMajor + ".0." + chromeBuild + "." + chromePatch
                + " Mobile Safari/537.36";
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("AdsViewerPrefs", Context.MODE_PRIVATE);

        // Restore geo-rotation index so we continue from where we left off
        countryRotationIndex = prefs.getInt("countryRotationIndex", 0) % GEO_ENDPOINTS.length;

        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        webView = findViewById(R.id.webview);
        setupWebView();

        webView.addJavascriptInterface(new AdCounterBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d(TAG, "Page started: " + url);
                injectSpoofScript(view);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page finished loading: " + url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                super.onReceivedError(view, request, error);
                String errUrl = (request != null && request.getUrl() != null)
                        ? request.getUrl().toString() : "?";
                boolean forMain = request != null && request.isForMainFrame();
                Log.e(TAG, "[WV-ERR] " + (forMain ? "MAIN" : "sub")
                        + " code=" + error.getErrorCode()
                        + " desc=" + error.getDescription()
                        + " url=" + errUrl);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                Log.d(TAG, "[JS] " + cm.message()
                        + " -- From line " + cm.lineNumber()
                        + " of " + cm.sourceId());
                return true;
            }
        });

        // Register VPN permission launcher BEFORE starting tunnel
        vpnPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Log.d(TAG, "[WARP] VPN permission granted");
                        startWarpTunnelForCurrentCountry(false);
                    } else {
                        Log.w(TAG, "[WARP] VPN permission denied; running without VPN");
                        Toast.makeText(this,
                                "VPN permission denied. Running without WARP.",
                                Toast.LENGTH_LONG).show();
                        startWithoutWarp();
                    }
                });

        wgBackend = new GoBackend(getApplicationContext());
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            Log.d(TAG, "[WARP] Requesting VPN permission from user");
            vpnPermissionLauncher.launch(prep);
        } else {
            Log.d(TAG, "[WARP] VPN permission already granted");
            startWarpTunnelForCurrentCountry(false);
        }
    }

    // ─── WebView setup ────────────────────────────────────────────────────────
    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        CookieManager.getInstance().setAcceptCookie(true);
    }

    // ─── JS fingerprint spoof injection ──────────────────────────────────────
    private void injectSpoofScript(WebView view) {
        String jsCode =
            "(function(){" +
            "  var langs = '" + currentLanguage + "'.split(',');" +
            "  try { Object.defineProperty(navigator, 'language', {" +
            "    get: function(){ return langs[0].split(';')[0]; }, configurable: true" +
            "  }); } catch(e) {}" +
            "  try { Object.defineProperty(navigator, 'languages', {" +
            "    get: function(){ return langs.map(function(l){ return l.split(';')[0]; }); }," +
            "    configurable: true" +
            "  }); } catch(e) {}" +
            "  try { Object.defineProperty(document, 'referrer', {" +
            "    get: function(){ return '" + currentReferer + "'; }, configurable: true" +
            "  }); } catch(e) {}" +
            // Block timezone leaking the real country
            "  try {" +
            "    var _tzOffset = " + getCountryTimezoneOffset(currentCountry) + ";" +
            "    var _DateOrig = Date;" +
            "    Date.prototype.getTimezoneOffset = function(){ return _tzOffset; };" +
            "  } catch(e) {}" +
            "  console.log('[SPOOF] country=" + currentCountry
                + " lang=' + navigator.language + ' ref=' + document.referrer);" +
            "})();";
        view.evaluateJavascript(jsCode, null);
    }

    /** Returns a plausible UTC offset (in minutes, as JS getTimezoneOffset returns) per country. */
    private int getCountryTimezoneOffset(String country) {
        switch (country) {
            case "US": return 300;   // UTC-5 (EST)
            case "GB": return 0;     // UTC+0
            case "DE": case "FR": case "IT": case "NL": case "PL": return -60;  // UTC+1
            case "SG": return -480;  // UTC+8
            case "JP": case "KR": return -540;  // UTC+9
            case "CA": return 300;   // UTC-5
            case "AU": return -600;  // UTC+10
            case "BR": return 180;   // UTC-3
            case "MX": return 360;   // UTC-6
            case "AE": return -240;  // UTC+4
            default:   return 0;
        }
    }

    // ─── WARP tunnel management ───────────────────────────────────────────────

    /** Start tunnel using the current geo-rotation slot. */
    private void startWarpTunnelForCurrentCountry(boolean forceFreshRegistration) {
        GeoEndpoint geo = GEO_ENDPOINTS[countryRotationIndex % GEO_ENDPOINTS.length];
        currentCountry = geo.countryCode;
        Log.d(TAG, "[GEO] Connecting to country: " + geo.countryCode
                + " via endpoint: " + geo.endpoint);
        startWarpTunnel(forceFreshRegistration, geo);
    }

    /** Advance to the next country in the rotation list and bring the tunnel up. */
    private void advanceToNextCountry() {
        countryRotationIndex = (countryRotationIndex + 1) % GEO_ENDPOINTS.length;
        // Persist so next app launch continues the rotation
        prefs.edit().putInt("countryRotationIndex", countryRotationIndex).apply();
        GeoEndpoint geo = GEO_ENDPOINTS[countryRotationIndex];
        currentCountry = geo.countryCode;
        Log.d(TAG, "[GEO] Rotating to next country: " + geo.countryCode
                + " (" + (countryRotationIndex + 1) + "/" + GEO_ENDPOINTS.length + ")");
        WarpRegistration.clearCache(prefs);
        startWarpTunnel(true, geo);
    }

    private void startWarpTunnel(final boolean forceFreshRegistration, final GeoEndpoint geo) {
        executor.execute(() -> {
            int attempt = 0;
            Exception lastErr = null;

            while (attempt < 3) {
                attempt++;
                try {
                    WarpRegistration.WarpConfig wc =
                            WarpRegistration.getOrRegister(prefs, forceFreshRegistration);

                    // Override the endpoint with our geo-selected one
                    String endpoint = (geo != null) ? geo.endpoint : wc.endpoint;
                    String serverPubKey = (geo != null) ? geo.serverPublicKey : wc.serverPublicKey;

                    Interface iface = new Interface.Builder()
                            .parsePrivateKey(wc.privateKeyBase64)
                            .parseAddresses(wc.v4Address + "/32, " + wc.v6Address + "/128")
                            .parseDnsServers("1.1.1.1, 1.0.0.1")
                            .build();

                    Peer peer = new Peer.Builder()
                            .parsePublicKey(serverPubKey)
                            .parseEndpoint(endpoint)
                            .parseAllowedIPs("0.0.0.0/0, ::/0")
                            .parsePersistentKeepalive("25")
                            .build();

                    Config cfg = new Config.Builder()
                            .setInterface(iface)
                            .addPeer(peer)
                            .build();

                    // Bring tunnel down first (idempotent reconnect)
                    try {
                        wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
                    } catch (Exception ignored) {}

                    wgBackend.setState(warpTunnel, Tunnel.State.UP, cfg);
                    warpUp = true;

                    String countryTag = (geo != null) ? geo.countryCode : "?";
                    Log.d(TAG, "[WARP] Tunnel UP → country=" + countryTag
                            + " endpoint=" + endpoint);

                    // Give WireGuard ~3 s for handshake then probe exit IP
                    Thread.sleep(3000);
                    checkCurrentIp();

                    // Update language & referer to match the new country
                    updateLocaleForCountry(countryTag);

                    handler.post(() -> {
                        Toast.makeText(MainActivity.this,
                                "WARP connected! Country: " + currentCountry
                                        + " | IP: " + currentExitIp,
                                Toast.LENGTH_LONG).show();
                        rotateFingerprintAndReload(true);
                        handler.postDelayed(rotateRunnable, 10_000);
                    });
                    return;

                } catch (Exception e) {
                    lastErr = e;
                    Log.e(TAG, "[WARP] Attempt " + attempt + " failed: " + e.getMessage(), e);
                    try {
                        Thread.sleep(1500L * attempt);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
            }

            Log.e(TAG, "[WARP] All attempts failed for " +
                    (geo != null ? geo.countryCode : "?"), lastErr);
            handler.post(() -> {
                Toast.makeText(MainActivity.this,
                        "WARP unavailable - trying next country",
                        Toast.LENGTH_SHORT).show();
                // Try the next country automatically instead of giving up
                advanceToNextCountry();
            });
        });
    }

    /** Set language/referer fields to match the currently active country. */
    private void updateLocaleForCountry(String country) {
        String lang = COUNTRY_LANGUAGE_MAP.get(country);
        if (lang != null) currentLanguage = lang;

        String[] refs = COUNTRY_REFERER_MAP.get(country);
        if (refs != null && refs.length > 0) {
            currentReferer = refs[random.nextInt(refs.length)];
        }

        Log.d(TAG, "[GEO] Locale updated → lang=" + currentLanguage
                + " referer=" + currentReferer);
    }

    private void startWithoutWarp() {
        Log.w(TAG, "[APP] Starting WITHOUT WARP (direct mode)");
        warpUp = false;
        currentExitIp = "direct";
        rotateFingerprintAndReload(true);
        handler.postDelayed(rotateRunnable, 10_000);
    }

    /**
     * Called every 500 ad loads.
     * Every Nth call we advance to a new country; otherwise we just bounce the tunnel
     * within the same country for a fresh IP.
     */
    private void rotateWarpIdentity() {
        if (!warpUp) {
            Log.w(TAG, "[WARP] Tunnel not up, attempting fresh start");
            startWarpTunnelForCurrentCountry(true);
            return;
        }

        rotationsSinceReregister++;
        if (rotationsSinceReregister >= REREGISTER_EVERY_N_ROTATIONS) {
            Log.d(TAG, "[GEO] Advancing to next country after "
                    + rotationsSinceReregister + " rotations");
            rotationsSinceReregister = 0;
            advanceToNextCountry();
        } else {
            Log.d(TAG, "[WARP] Bouncing tunnel in same country ("
                    + currentCountry + ") rotation "
                    + rotationsSinceReregister + "/" + REREGISTER_EVERY_N_ROTATIONS);
            WarpRegistration.clearCache(prefs);
            startWarpTunnelForCurrentCountry(true);
        }
    }

    // ─── IP check ─────────────────────────────────────────────────────────────
    private void checkCurrentIp() {
        // Try multiple IP-check services for resilience
        String[] ipServices = {
            "https://api.ipify.org?format=text",
            "https://ipecho.net/plain",
            "https://checkip.amazonaws.com"
        };

        for (String serviceUrl : ipServices) {
            try {
                URL url = new URL(serviceUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                BufferedReader reader =
                        new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String ip = reader.readLine();
                reader.close();
                conn.disconnect();

                if (ip != null && !ip.isEmpty()) {
                    currentExitIp = ip.trim();
                    Log.d(TAG, "[WARP] Exit IP=" + currentExitIp
                            + " country=" + currentCountry
                            + " via " + serviceUrl);
                    return;
                }
            } catch (Exception e) {
                Log.w(TAG, "[WARP] IP check failed (" + serviceUrl + "): " + e.getMessage());
            }
        }
        currentExitIp = "unknown";
    }

    // ─── Rotation runnable ────────────────────────────────────────────────────
    private final Runnable rotateRunnable = new Runnable() {
        @Override
        public void run() {
            rotateFingerprintAndReload(false);
            handler.postDelayed(this, 10_000);
        }
    };

    // ─── Fingerprint rotation & page reload ───────────────────────────────────
    private void rotateFingerprintAndReload(boolean firstLoad) {
        rotationCount++;

        String ua = randomUserAgent();
        webView.getSettings().setUserAgentString(ua);

        // Use country-matched language/referer; fall back to random
        String lang = COUNTRY_LANGUAGE_MAP.get(currentCountry);
        currentLanguage = (lang != null) ? lang : "en-US,en;q=0.9";

        String[] countryRefs = COUNTRY_REFERER_MAP.get(currentCountry);
        if (countryRefs != null && countryRefs.length > 0) {
            currentReferer = countryRefs[random.nextInt(countryRefs.length)];
        } else {
            currentReferer = "https://www.google.com/";
        }

        Log.d(TAG, "=== ROTATION #" + rotationCount + " ===");
        Log.d(TAG, "Country  : " + currentCountry);
        Log.d(TAG, "Exit IP  : " + currentExitIp + (warpUp ? " [WARP]" : " [DIRECT]"));
        Log.d(TAG, "UA       : " + ua.substring(0, Math.min(60, ua.length())) + "...");
        Log.d(TAG, "Language : " + currentLanguage);
        Log.d(TAG, "Referer  : " + currentReferer);

        // Clear all browser state so each rotation is a fresh session
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.removeSessionCookies(null);
        cm.flush();
        WebStorage.getInstance().deleteAllData();
        webView.clearCache(true);
        webView.clearHistory();
        webView.clearFormData();
        webView.clearSslPreferences();

        String visitorId = UUID.randomUUID().toString().replace("-", "");
        long ts = System.currentTimeMillis();
        String url = "file:///android_asset/index.html?vid=" + visitorId
                + "&t=" + ts + "&country=" + currentCountry;

        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", currentLanguage);
        headers.put("Referer", currentReferer);
        headers.put("X-Forwarded-For", currentExitIp.equals("unknown") ? "" : currentExitIp);

        Log.d(TAG, "Loading  : " + url);
        webView.loadUrl(url, headers);
    }

    // ─── Lifecycle cleanup ────────────────────────────────────────────────────
    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        executor.shutdown();
        try {
            if (wgBackend != null && warpUp) {
                wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
            }
        } catch (Exception e) {
            Log.w(TAG, "[WARP] Error tearing down tunnel: " + e.getMessage());
        }
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Keep rotation alive in background; screen stays on via FLAG_KEEP_SCREEN_ON
        Log.d(TAG, "[APP] onPause – rotation continues in background");
    }

    @Override
    public void onBackPressed() {
        // Prevent accidental exit; send to background instead
        moveTaskToBack(true);
    }
}