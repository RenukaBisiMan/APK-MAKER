package com.adsviewer.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;
import com.wireguard.config.Interface;
import com.wireguard.config.Peer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Main activity for AdsViewer application.
 * Manages WebView-based ad viewing with WARP VPN rotation and browser fingerprint spoofing.
 */
public class MainActivity extends AppCompatActivity {

    // =============================================================================================
    // Constants
    // =============================================================================================

    private static final String TAG = "AdsViewer";
    private static final String PREFS_NAME = "AdsViewerPrefs";
    private static final String PREF_AD_COUNT = "adLoadCount";

    // Rotation configuration
    private static final long ROTATION_INTERVAL_MS = 10_000L; // 10 seconds
    private static final int ADS_PER_IP_ROTATION = 500;
    private static final int REREGISTER_EVERY_N_ROTATIONS = 5;

    // WARP/VPN configuration
    private static final int WARP_STARTUP_DELAY_MS = 3000;
    private static final int WARP_MAX_RETRY_ATTEMPTS = 3;
    private static final int WARP_RETRY_BASE_DELAY_MS = 1500;

    // Network configuration
    private static final int HTTP_CONNECT_TIMEOUT_MS = 15000;
    private static final int HTTP_READ_TIMEOUT_MS = 15000;
    private static final String IP_CHECK_URL = "https://api.ipify.org?format=text";

    // Device models for user agent spoofing
    private static final String[] DEVICE_MODELS = {
            "SM-S908B", "SM-S918B", "SM-A546B", "SM-G998U", "SM-N986U", "SM-F946B", "SM-A536E",
            "Pixel 6", "Pixel 6 Pro", "Pixel 7", "Pixel 7 Pro", "Pixel 8", "Pixel 8 Pro", "Pixel 9", "Pixel 9 Pro",
            "Redmi Note 12", "Redmi Note 13", "Redmi Note 11", "M2102J20SG", "M2103K19PG", "23021RAA2Y",
            "OnePlus 11", "OnePlus 12", "OnePlus 9 Pro", "PJF110", "CPH2581",
            "Nokia G50", "Nokia X20", "TA-1456",
            "moto g stylus 5G", "motorola edge 40", "XT2255-1",
            "ASUS_AI2202", "ASUS_I003D",
            "vivo X100", "V2309", "V2241A",
            "POCO X6 Pro", "POCO F5", "23076PC4BG",
            "realme GT 5", "RMX3700",
            "Honor Magic5", "PGT-N19",
            "Infinix HOT 30", "Infinix X6831"
    };

    // Language codes for Accept-Language spoofing
    private static final String[] LANGUAGES = {
            "en-US,en;q=0.9", "en-GB,en;q=0.8", "es-ES,es;q=0.9", "pt-BR,pt;q=0.9",
            "fr-FR,fr;q=0.9", "de-DE,de;q=0.9", "ar-SA,ar;q=0.9", "hi-IN,hi;q=0.9",
            "ru-RU,ru;q=0.9", "id-ID,id;q=0.9", "tr-TR,tr;q=0.9", "ja-JP,ja;q=0.9",
            "zh-CN,zh;q=0.9", "ko-KR,ko;q=0.9", "it-IT,it;q=0.9", "pl-PL,pl;q=0.9"
    };

    // Referer URLs for referrer spoofing
    private static final String[] REFERERS = {
            "https://www.google.com/", "https://m.facebook.com/", "https://www.bing.com/",
            "https://duckduckgo.com/", "https://t.co/abc", "https://www.reddit.com/",
            "https://news.ycombinator.com/", "https://www.youtube.com/", "https://twitter.com/",
            "https://www.instagram.com/", "https://www.tiktok.com/", "https://www.linkedin.com/",
            "https://www.pinterest.com/", "https://www.snapchat.com/"
    };

    // =============================================================================================
    // Instance Variables
    // =============================================================================================

    // UI components
    private WebView webView;

    // Threading
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ExecutorService backgroundExecutor;
    private final AtomicBoolean isDestroyed = new AtomicBoolean(false);

    // Preferences
    private SharedPreferences prefs;

    // Randomization
    private final Random random = new Random();

    // Fingerprint state
    private volatile String currentLanguage = LANGUAGES[0];
    private volatile String currentReferer = REFERERS[0];
    private final AtomicInteger rotationCount = new AtomicInteger(0);

    // WARP/VPN state
    private Backend wgBackend;
    private final WarpTunnel warpTunnel = new WarpTunnel();
    private final AtomicBoolean warpUp = new AtomicBoolean(false);
    private final AtomicInteger rotationsSinceReregister = new AtomicInteger(0);
    private volatile String currentExitIp = "unknown";

    // Activity result launchers
    private ActivityResultLauncher<Intent> vpnPermissionLauncher;

    // Periodic rotation runnable
    private final Runnable rotateRunnable = new Runnable() {
        @Override
        public void run() {
            if (isDestroyed.get()) {
                return;
            }
            rotateFingerprintAndReload(false);
            mainHandler.postDelayed(this, ROTATION_INTERVAL_MS);
        }
    };

    // =============================================================================================
    // Inner Classes
    // =============================================================================================

    /**
     * Tunnel descriptor required by WireGuard GoBackend.
     */
    private static class WarpTunnel implements Tunnel {
        @NonNull
        @Override
        public String getName() {
            return "warp";
        }

        @Override
        public void onStateChange(@NonNull State newState) {
            Log.d(TAG, "[WARP] Tunnel state changed: " + newState);
        }
    }

    /**
     * JavaScript bridge interface for ad counting and IP rotation triggering.
     */
    public class AdCounterBridge {
        @JavascriptInterface
        public int getAdLoadCount() {
            return prefs.getInt(PREF_AD_COUNT, 0);
        }

        @JavascriptInterface
        public void setAdLoadCount(int count) {
            if (count < 0) {
                Log.w(TAG, "[BRIDGE] Invalid ad count received: " + count);
                return;
            }

            prefs.edit().putInt(PREF_AD_COUNT, count).apply();
            Log.d(TAG, "[BRIDGE] Ad count saved: " + count);

            if (count > 0 && count % ADS_PER_IP_ROTATION == 0) {
                Log.d(TAG, "[BRIDGE] Ad threshold (" + count + ") reached, rotating WARP identity");
                mainHandler.post(() -> rotateWarpIdentity());
            }
        }
    }

    // =============================================================================================
    // Lifecycle Methods
    // =============================================================================================

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize shared preferences early
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Initialize background executor
        backgroundExecutor = Executors.newSingleThreadExecutor();

        // Setup window flags (keep screen on)
        setupWindowFlags();

        // Set content view
        setContentView(R.layout.activity_main);

        // Setup immersive fullscreen mode
        setupImmersiveMode();

        // Setup modern back button handler
        setupBackPressHandler();

        // Initialize WebView
        webView = findViewById(R.id.webview);
        if (webView == null) {
            Log.e(TAG, "WebView not found in layout - cannot continue");
            finish();
            return;
        }

        setupWebView();

        // Register VPN permission launcher
        registerVpnPermissionLauncher();

        // Initialize WireGuard backend and start WARP
        initializeWarpVpn();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
            webView.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        isDestroyed.set(true);

        // Remove all pending handler callbacks
        mainHandler.removeCallbacksAndMessages(null);

        // Shutdown WARP tunnel
        shutdownWarpTunnel();

        // Shutdown executor service
        shutdownExecutor();

        // Cleanup WebView
        cleanupWebView();

        super.onDestroy();
    }

    // =============================================================================================
    // Setup Methods
    // =============================================================================================

    /**
     * Configure window to keep screen on during ad viewing.
     */
    private void setupWindowFlags() {
        Window window = getWindow();
        if (window != null) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    /**
     * Setup immersive fullscreen mode using modern WindowInsetsController API.
     * Falls back to deprecated API for older Android versions.
     */
    private void setupImmersiveMode() {
        try {
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
            WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(
                    getWindow(),
                    getWindow().getDecorView()
            );
            if (controller != null) {
                controller.hide(WindowInsetsCompat.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } catch (Exception e) {
            Log.w(TAG, "Failed to setup immersive mode with modern API, using fallback", e);
            setupImmersiveModeLegacy();
        }
    }

    /**
     * Fallback immersive mode implementation for Android versions < 11.
     */
    @SuppressWarnings("deprecation")
    private void setupImmersiveModeLegacy() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
    }

    /**
     * Setup back button handler using modern OnBackPressedDispatcher.
     * Minimizes app to background instead of destroying it.
     */
    private void setupBackPressHandler() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                moveTaskToBack(true);
            }
        });
    }

    /**
     * Configure WebView with all required settings for ad viewing.
     */
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        WebSettings settings = webView.getSettings();

        // JavaScript settings
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        // Storage settings
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // Content settings
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // Display settings
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setSupportZoom(false);

        // Window settings
        settings.setSupportMultipleWindows(false);

        // Cookie settings
        setupCookies();

        // Add JavaScript bridge for ad counting
        webView.addJavascriptInterface(new AdCounterBridge(), "AndroidBridge");

        // Set custom WebView clients
        webView.setWebViewClient(new CustomWebViewClient());
        webView.setWebChromeClient(new CustomWebChromeClient());
    }

    /**
     * Configure cookie manager for third-party cookie support.
     */
    private void setupCookies() {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }
    }

    /**
     * Register activity result launcher for VPN permission request.
     */
    private void registerVpnPermissionLauncher() {
        vpnPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Log.d(TAG, "[WARP] VPN permission granted by user");
                        startWarpTunnel(false);
                    } else {
                        Log.w(TAG, "[WARP] VPN permission denied by user");
                        showToast("VPN permission denied. Running without WARP.");
                        startWithoutWarp();
                    }
                }
        );
    }

    // =============================================================================================
    // WARP/VPN Methods
    // =============================================================================================

    /**
     * Initialize WireGuard backend and request VPN permission if needed.
     */
    private void initializeWarpVpn() {
        try {
            wgBackend = new GoBackend(getApplicationContext());
            requestVpnPermission();
        } catch (Exception e) {
            Log.e(TAG, "[WARP] Failed to initialize WireGuard backend", e);
            showToast("WARP initialization failed. Running without VPN.");
            startWithoutWarp();
        }
    }

    /**
     * Request VPN permission from user or start tunnel if already granted.
     */
    private void requestVpnPermission() {
        Intent prepareIntent = VpnService.prepare(this);
        if (prepareIntent != null) {
            Log.d(TAG, "[WARP] Requesting VPN permission from user");
            vpnPermissionLauncher.launch(prepareIntent);
        } else {
            Log.d(TAG, "[WARP] VPN permission already granted");
            startWarpTunnel(false);
        }
    }

    /**
     * Start WARP VPN tunnel in background thread with retry logic.
     *
     * @param forceFreshRegistration If true, register new WARP device instead of reusing cached credentials
     */
    private void startWarpTunnel(boolean forceFreshRegistration) {
        if (isDestroyed.get()) {
            return;
        }

        backgroundExecutor.execute(() -> {
            Exception lastError = null;

            for (int attempt = 1; attempt <= WARP_MAX_RETRY_ATTEMPTS; attempt++) {
                if (isDestroyed.get()) {
                    return;
                }

                try {
                    Log.d(TAG, "[WARP] Starting tunnel (attempt " + attempt + "/" + WARP_MAX_RETRY_ATTEMPTS + ")");

                    // Get or register WARP configuration
                    WarpRegistration.WarpConfig warpConfig = WarpRegistration.getOrRegister(
                            prefs,
                            forceFreshRegistration
                    );

                    // Build WireGuard interface configuration
                    Interface iface = new Interface.Builder()
                            .parsePrivateKey(warpConfig.privateKeyBase64)
                            .parseAddresses(warpConfig.v4Address + "/32, " + warpConfig.v6Address + "/128")
                            .parseDnsServers("1.1.1.1, 1.0.0.1")
                            .build();

                    // Build WireGuard peer configuration
                    Peer peer = new Peer.Builder()
                            .parsePublicKey(warpConfig.serverPublicKey)
                            .parseEndpoint(warpConfig.endpoint)
                            .parseAllowedIPs("0.0.0.0/0, ::/0")
                            .parsePersistentKeepalive("25")
                            .build();

                    // Build complete WireGuard configuration
                    Config config = new Config.Builder()
                            .setInterface(iface)
                            .addPeer(peer)
                            .build();

                    // Bring down existing tunnel if already up (idempotent)
                    try {
                        if (wgBackend != null) {
                            wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
                        }
                    } catch (Exception ignored) {
                        // Ignore errors when bringing down
                    }

                    // Bring up tunnel
                    if (wgBackend != null) {
                        wgBackend.setState(warpTunnel, Tunnel.State.UP, config);
                        warpUp.set(true);
                        Log.d(TAG, "[WARP] Tunnel brought UP successfully");

                        // Wait for WireGuard handshake
                        Thread.sleep(WARP_STARTUP_DELAY_MS);

                        // Check current exit IP
                        checkCurrentIp();

                        // Notify UI of success
                        mainHandler.post(() -> {
                            if (!isDestroyed.get()) {
                                showToast("WARP connected! IP rotates every " + ADS_PER_IP_ROTATION + " ads");
                                rotateFingerprintAndReload(true);
                                mainHandler.postDelayed(rotateRunnable, ROTATION_INTERVAL_MS);
                            }
                        });
                    }

                    return; // Success - exit retry loop

                } catch (Exception e) {
                    lastError = e;
                    Log.e(TAG, "[WARP] Attempt " + attempt + " failed", e);

                    // Retry with exponential backoff
                    if (attempt < WARP_MAX_RETRY_ATTEMPTS) {
                        try {
                            long delay = (long) WARP_RETRY_BASE_DELAY_MS * attempt;
                            Thread.sleep(delay);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            return;
                        }
                    }
                }
            }

            // All attempts failed
            Log.e(TAG, "[WARP] All " + WARP_MAX_RETRY_ATTEMPTS + " registration attempts failed", lastError);
            mainHandler.post(() -> {
                if (!isDestroyed.get()) {
                    showToast("WARP unavailable - running without VPN");
                    startWithoutWarp();
                }
            });
        });
    }

    /**
     * Start application without WARP VPN (direct internet connection).
     */
    private void startWithoutWarp() {
        if (isDestroyed.get()) {
            return;
        }

        Log.w(TAG, "[APP] Starting without WARP (direct connection mode)");
        warpUp.set(false);
        currentExitIp = "direct";
        rotateFingerprintAndReload(true);
        mainHandler.postDelayed(rotateRunnable, ROTATION_INTERVAL_MS);
    }

    /**
     * Rotate WARP identity to get new exit IP.
     * Re-registers every Nth rotation, otherwise just bounces tunnel.
     */
    private void rotateWarpIdentity() {
        if (!warpUp.get()) {
            Log.w(TAG, "[WARP] Tunnel not up, attempting fresh start");
            startWarpTunnel(true);
            return;
        }

        int rotations = rotationsSinceReregister.incrementAndGet();
        boolean shouldReregister = rotations >= REREGISTER_EVERY_N_ROTATIONS;

        if (shouldReregister) {
            Log.d(TAG, "[WARP] Re-registering new device for fresh exit IP");
            rotationsSinceReregister.set(0);
            WarpRegistration.clearCache(prefs);
            startWarpTunnel(true);
        } else {
            Log.d(TAG, "[WARP] Bouncing tunnel for IP refresh (" + rotations + "/" + REREGISTER_EVERY_N_ROTATIONS + ")");
            startWarpTunnel(false);
        }
    }

    /**
     * Check current exit IP address via external API (runs on background thread).
     */
    private void checkCurrentIp() {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {
            URL url = new URL(IP_CHECK_URL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(HTTP_CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(HTTP_READ_TIMEOUT_MS);
            connection.setRequestMethod("GET");

            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String ip = reader.readLine();

            if (ip != null && !ip.trim().isEmpty()) {
                currentExitIp = ip.trim();
                Log.d(TAG, "[WARP] Current exit IP: " + currentExitIp);
            }

        } catch (Exception e) {
            Log.e(TAG, "[WARP] Error checking exit IP", e);
            currentExitIp = "unknown";
        } finally {
            // Cleanup resources
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception ignored) {
                }
            }
            if (connection != null) {
                try {
                    connection.disconnect();
                } catch (Exception ignored) {
                }
            }
        }
    }

    /**
     * Gracefully shutdown WARP tunnel.
     */
    private void shutdownWarpTunnel() {
        try {
            if (wgBackend != null && warpUp.get()) {
                Log.d(TAG, "[WARP] Shutting down tunnel");
                wgBackend.setState(warpTunnel, Tunnel.State.DOWN, null);
                warpUp.set(false);
            }
        } catch (Exception e) {
            Log.w(TAG, "[WARP] Error during tunnel shutdown", e);
        }
    }

    // =============================================================================================
    // Fingerprinting & Rotation Methods
    // =============================================================================================

    /**
     * Rotate browser fingerprint (user agent, language, referer) and reload page.
     *
     * @param isFirstLoad True if this is the initial page load
     */
    private void rotateFingerprintAndReload(boolean isFirstLoad) {
        if (isDestroyed.get() || webView == null) {
            return;
        }

        int rotation = rotationCount.incrementAndGet();

        // Generate new random fingerprint
        String userAgent = randomUserAgent();
        currentLanguage = randomElement(LANGUAGES);
        currentReferer = randomElement(REFERERS);

        // Apply user agent to WebView
        webView.getSettings().setUserAgentString(userAgent);

        // Log rotation details
        logRotation(rotation, userAgent);

        // Clear all browsing data for fresh session
        clearBrowsingData();

        // Generate unique page URL
        String url = generatePageUrl();

        // Build custom headers
        Map<String, String> headers = buildHeaders();

        // Load page
        Log.d(TAG, "[WebView] Loading: " + url);
        webView.loadUrl(url, headers);
    }

    /**
     * Log current rotation details for debugging.
     */
    private void logRotation(int rotation, String userAgent) {
        Log.d(TAG, "=== ROTATION #" + rotation + " ===");
        Log.d(TAG, "User-Agent: " + truncate(userAgent, 60));
        Log.d(TAG, "Language: " + currentLanguage);
        Log.d(TAG, "Referer: " + currentReferer);
        Log.d(TAG, "Exit IP: " + currentExitIp + (warpUp.get() ? " [WARP ACTIVE]" : " [DIRECT]"));
    }

    /**
     * Clear all browsing data (cookies, cache, storage, history).
     */
    private void clearBrowsingData() {
        if (webView == null) {
            return;
        }

        try {
            // Clear cookies
            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.removeAllCookies(null);
            cookieManager.removeSessionCookies(null);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.flush();
            }

            // Clear web storage
            WebStorage.getInstance().deleteAllData();

            // Clear cache and history
            webView.clearCache(true);
            webView.clearHistory();
            webView.clearFormData();
            webView.clearSslPreferences();

        } catch (Exception e) {
            Log.e(TAG, "Error clearing browsing data", e);
        }
    }

    /**
     * Generate page URL with unique visitor ID and timestamp.
     */
    private String generatePageUrl() {
        String visitorId = UUID.randomUUID().toString().replace("-", "");
        long timestamp = System.currentTimeMillis();
        return String.format(Locale.US,
                "file:///android_asset/index.html?vid=%s&t=%d",
                visitorId,
                timestamp
        );
    }

    /**
     * Build HTTP headers for WebView request (language, referer).
     */
    private Map<String, String> buildHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", currentLanguage);
        headers.put("Referer", currentReferer);
        return headers;
    }

    // =============================================================================================
    // User Agent Generation
    // =============================================================================================

    /**
     * Generate random user agent string (10% iOS, 90% Android).
     */
    private String randomUserAgent() {
        if (random.nextInt(10) == 0) {
            return generateiOSUserAgent();
        }
        return generateAndroidUserAgent();
    }

    /**
     * Generate realistic iOS Chrome user agent.
     */
    private String generateiOSUserAgent() {
        int iosMajor = 14 + random.nextInt(5); // iOS 14-18
        int iosMinor = random.nextInt(7); // 0-6
        int chromeMajor = 110 + random.nextInt(25); // Chrome 110-134
        int chromeMinor = random.nextInt(7000);
        int chromePatch = random.nextInt(250);

        return String.format(Locale.US,
                "Mozilla/5.0 (iPhone; CPU iPhone OS %d_%d like Mac OS X) " +
                        "AppleWebKit/605.1.15 (KHTML, like Gecko) " +
                        "CriOS/%d.0.%d.%d Mobile/15E148 Safari/604.1",
                iosMajor, iosMinor, chromeMajor, chromeMinor, chromePatch
        );
    }

    /**
     * Generate realistic Android Chrome user agent.
     */
    private String generateAndroidUserAgent() {
        int androidMajor = 9 + random.nextInt(7); // Android 9-15
        int chromeMajor = 100 + random.nextInt(35); // Chrome 100-134
        int chromeBuild = 1000 + random.nextInt(7500);
        int chromePatch = random.nextInt(250);

        String model = randomElement(DEVICE_MODELS);
        String buildId = random.nextInt(2) == 0 ? "" : " Build/" + randomBuildId();

        // 33% chance to add device variant suffix
        if (random.nextInt(3) == 0) {
            char variant = (char) ('A' + random.nextInt(26));
            int variantNum = 100 + random.nextInt(900);
            model = model + "-" + variant + variantNum;
        }

        return String.format(Locale.US,
                "Mozilla/5.0 (Linux; Android %d; %s%s) " +
                        "AppleWebKit/537.36 (KHTML, like Gecko) " +
                        "Chrome/%d.0.%d.%d Mobile Safari/537.36",
                androidMajor, model, buildId, chromeMajor, chromeBuild, chromePatch
        );
    }

/**
 * Generate random Android build ID.
 */
private String randomBuildId() {
    char[] prefixes = {'U', 'T', 'S', 'R', 'Q', 'P'};
    char prefix = prefixes[random.nextInt(prefixes.length)];
    int version = 1 + random.nextInt(2);
    int year = 22 + random.nextInt(4);
    int month = 1 + random.nextInt(12);
    int day = 1 + random.nextInt(28);
    int patch = random.nextInt(40);

    return String.format(Locale.US,
            "%cP%dA.%02d%02d%02d.%03d",
            prefix, version, year, month, day, patch);
}

// =============================================================================================
// WebView Clients
// =====================================================================================================================================
    // WebView Clients
    // =============================================================================================

    /**
     * Custom WebViewClient for injecting fingerprint spoofing scripts and handling errors.
     */
    private class CustomWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            Log.d(TAG, "[WebView] Page started: " + url);
            injectSpoofingScript(view);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            Log.d(TAG, "[WebView] Page finished: " + url);
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);

            if (request == null || error == null) {
                return;
            }

            String url = request.getUrl() != null ? request.getUrl().toString() : "unknown";
            boolean isMainFrame = request.isForMainFrame();
            int errorCode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? error.getErrorCode() : -1;
            CharSequence description = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? error.getDescription()
                    : "unknown";

            Log.e(TAG, String.format(Locale.US,
                    "[WebView] Error [%s] code=%d desc=%s url=%s",
                    isMainFrame ? "MAIN" : "sub",
                    errorCode,
                    description,
                    url
            ));
        }

        /**
         * Inject JavaScript to spoof navigator properties and document.referrer.
         */
        private void injectSpoofingScript(WebView view) {
            if (view == null || isDestroyed.get()) {
                return;
            }

            String script = buildSpoofingScript();
            view.evaluateJavascript(script, null);
        }

        /**
         * Build JavaScript code for fingerprint spoofing.
         */
        private String buildSpoofingScript() {
            return "(function(){" +
                    "  var langs = '" + currentLanguage + "'.split(',');" +
                    "  try {" +
                    "    Object.defineProperty(navigator, 'language', {" +
                    "      get: function(){ return langs[0].split(';')[0]; }," +
                    "      configurable: true" +
                    "    });" +
                    "  } catch(e) {}" +
                    "  try {" +
                    "    Object.defineProperty(navigator, 'languages', {" +
                    "      get: function(){ return langs.map(function(l){ return l.split(';')[0]; }); }," +
                    "      configurable: true" +
                    "    });" +
                    "  } catch(e) {}" +
                    "  try {" +
                    "    Object.defineProperty(document, 'referrer', {" +
                    "      get: function(){ return '" + currentReferer + "'; }," +
                    "      configurable: true" +
                    "    });" +
                    "  } catch(e) {}" +
                    "  console.log('[SPOOF] Language:', navigator.language, 'Referrer:', document.referrer);" +
                    "})();";
        }
    }

    /**
     * Custom WebChromeClient for logging JavaScript console messages.
     */
    private class CustomWebChromeClient extends WebChromeClient {

        @Override
        public boolean onConsoleMessage(@NonNull ConsoleMessage consoleMessage) {
            Log.d(TAG, String.format(Locale.US,
                    "[JS] %s -- Line %d of %s",
                    consoleMessage.message(),
                    consoleMessage.lineNumber(),
                    consoleMessage.sourceId()
            ));
            return true;
        }
    }

    // =============================================================================================
    // Cleanup Methods
    // =============================================================================================

    /**
     * Properly cleanup WebView to prevent memory leaks.
     */
    private void cleanupWebView() {
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.setWebViewClient(null);
                webView.setWebChromeClient(null);
                webView.removeJavascriptInterface("AndroidBridge");
                webView.clearHistory();
                webView.clearCache(true);
                webView.loadUrl("about:blank");
                webView.onPause();
                webView.removeAllViews();
                webView.destroyDrawingCache();
                webView.destroy();
                webView = null;
            } catch (Exception e) {
                Log.e(TAG, "Error during WebView cleanup", e);
            }
        }
    }

    /**
     * Gracefully shutdown background executor service.
     */
    private void shutdownExecutor() {
        if (backgroundExecutor != null && !backgroundExecutor.isShutdown()) {
            try {
                backgroundExecutor.shutdown();
                if (!backgroundExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    backgroundExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                backgroundExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }

    // =============================================================================================
    // Utility Methods
    // =============================================================================================

    /**
     * Get random element from array.
     */
    private <T> T randomElement(T[] array) {
        return array[random.nextInt(array.length)];
    }

    /**
     * Truncate string to maximum length with ellipsis.
     */
    private String truncate(String text, int maxLength) {
        if (text == null) {
            return "";
        }
        if (text.length() <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength) + "...";
    }

    /**
     * Show toast message on main thread (safe to call from background).
     */
    private void showToast(String message) {
        mainHandler.post(() -> {
            if (!isDestroyed.get()) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }
}