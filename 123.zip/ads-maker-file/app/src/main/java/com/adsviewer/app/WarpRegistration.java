package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Handles Cloudflare WARP device registration.
 *
 * Uses the public consumer endpoint (same one wgcf and the official 1.1.1.1 app hit):
 *   POST https://api.cloudflareclient.com/v0a2405/reg
 *
 * Each call returns a fresh free-tier WARP identity (WireGuard server pubkey, endpoint,
 * client v4/v6 addresses, and a base64 client_id used as WireGuard "reserved" bytes).
 *
 * We persist the resulting config in SharedPreferences so the app reuses the same device
 * unless we explicitly request rotation (forceFreshRegistration).
 *
 * Thread-safe: Multiple concurrent calls are serialized via internal synchronization.
 */
public class WarpRegistration {
    private static final String TAG = "AdsViewer/WARP-REG";

    private static final String REG_URL = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String UA = "okhttp/3.12.1";
    private static final String CF_CLIENT_VERSION = "a-6.30-3596";

    // SharedPreferences keys
    private static final String K_PRIV = "warp_priv";
    private static final String K_PUB = "warp_pub";
    private static final String K_SRV_PUB = "warp_srv_pub";
    private static final String K_ENDPOINT = "warp_endpoint";
    private static final String K_V4 = "warp_v4";
    private static final String K_V6 = "warp_v6";
    private static final String K_CLIENT_ID = "warp_client_id";

    // JSON field names - constants prevent typos and improve maintainability
    private static final String JSON_KEY = "key";
    private static final String JSON_INSTALL_ID = "install_id";
    private static final String JSON_FCM_TOKEN = "fcm_token";
    private static final String JSON_TOS = "tos";
    private static final String JSON_MODEL = "model";
    private static final String JSON_TYPE = "type";
    private static final String JSON_LOCALE = "locale";
    private static final String JSON_CONFIG = "config";
    private static final String JSON_PEERS = "peers";
    private static final String JSON_PUBLIC_KEY = "public_key";
    private static final String JSON_ENDPOINT = "endpoint";
    private static final String JSON_HOST = "host";
    private static final String JSON_INTERFACE = "interface";
    private static final String JSON_ADDRESSES = "addresses";
    private static final String JSON_V4 = "v4";
    private static final String JSON_V6 = "v6";
    private static final String JSON_CLIENT_ID = "client_id";

    // Reusable MediaType - parsing is expensive, result is immutable
    private static final MediaType JSON_MEDIA_TYPE = 
            MediaType.parse("application/json; charset=utf-8");

    // Synchronization lock to prevent concurrent registration attempts
    private static final Object REGISTRATION_LOCK = new Object();

    public static class WarpConfig {
        public String privateKeyBase64;     // our WireGuard private key
        public String publicKeyBase64;      // our WireGuard public key
        public String serverPublicKey;      // Cloudflare's WireGuard pubkey
        public String endpoint;             // host:port
        public String v4Address;            // 172.16.0.x
        public String v6Address;            // 2606:...
        public String clientId;             // base64, used as 'reserved' bytes
    }

    /**
     * Loads cached config or registers a new device with Cloudflare.
     * 
     * This method is thread-safe and can be called from any background thread.
     * Concurrent calls are serialized internally.
     * 
     * @param prefs SharedPreferences instance for caching (must not be null)
     * @param forceFreshRegistration if true, ignores cached state and registers anew (rotation)
     * @return WarpConfig with all registration details
     * @throws Exception on network errors, invalid responses, or crypto failures
     * @throws IllegalArgumentException if prefs is null
     */
    public static WarpConfig getOrRegister(SharedPreferences prefs, boolean forceFreshRegistration)
            throws Exception {

        if (prefs == null) {
            throw new IllegalArgumentException("SharedPreferences cannot be null");
        }

        // Serialize all registration operations to prevent:
        // - Duplicate API calls to Cloudflare
        // - Race conditions on SharedPreferences read/write
        // - Partial config state visibility
        synchronized (REGISTRATION_LOCK) {
            // Check cache first (unless forced fresh registration)
            if (!forceFreshRegistration && prefs.contains(K_PRIV) && prefs.contains(K_SRV_PUB)) {
                WarpConfig cached = loadCachedConfig(prefs);
                if (cached != null) {
                    Log.d(TAG, "Reusing cached WARP registration: v4=" + cached.v4Address);
                    return cached;
                }
                // Cache read failed, fall through to registration
                Log.d(TAG, "Cached WARP config unreadable, re-registering");
            }

            return performRegistration(prefs);
        }
    }

    /**
     * Attempts to load config from SharedPreferences cache.
     * @return WarpConfig if cache valid, null if cache corrupted/incomplete
     */
    private static WarpConfig loadCachedConfig(SharedPreferences prefs) {
        try {
            WarpConfig c = new WarpConfig();
            c.privateKeyBase64 = prefs.getString(K_PRIV, null);
            c.publicKeyBase64 = prefs.getString(K_PUB, null);
            c.serverPublicKey = prefs.getString(K_SRV_PUB, null);
            c.endpoint = prefs.getString(K_ENDPOINT, null);
            c.v4Address = prefs.getString(K_V4, null);
            c.v6Address = prefs.getString(K_V6, null);
            c.clientId = prefs.getString(K_CLIENT_ID, null);
            return c;
        } catch (Exception e) {
            // SharedPreferences corruption or unexpected runtime exception
            Log.e(TAG, "Failed to load cached WARP config", e);
            return null;
        }
    }

    /**
     * Performs fresh registration with Cloudflare WARP API.
     * Generates new keypair, sends registration request, parses response, validates, and caches.
     */
    private static WarpConfig performRegistration(SharedPreferences prefs) throws Exception {
        Log.d(TAG, "Registering new WARP device with Cloudflare...");

        // Generate fresh WireGuard keypair locally
        KeyPair kp = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64 = kp.getPublicKey().toBase64();

        // Build registration request body (matches official client structure)
        JSONObject body = new JSONObject();
        body.put(JSON_KEY, pubB64);
        body.put(JSON_INSTALL_ID, "");
        body.put(JSON_FCM_TOKEN, "");
        body.put(JSON_TOS, iso8601Now());
        body.put(JSON_MODEL, "PC");
        body.put(JSON_TYPE, "Android");
        body.put(JSON_LOCALE, "en_US");

        // Create HTTP client with production timeouts
        OkHttpClient http = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();

        Request req = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent", UA)
                .header("CF-Client-Version", CF_CLIENT_VERSION)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(body.toString(), JSON_MEDIA_TYPE))
                .build();

        // Execute registration request
        String respText;
        try (Response resp = http.newCall(req).execute()) {
            // Check HTTP status before reading body
            if (!resp.isSuccessful()) {
                ResponseBody errorBody = resp.body();
                String errorText = (errorBody != null) ? errorBody.string() : "";
                throw new IOException("WARP reg HTTP " + resp.code() + ": " + errorText);
            }

            // Validate response body exists
            ResponseBody rb = resp.body();
            if (rb == null) {
                throw new IOException("WARP reg returned null response body (HTTP " + 
                        resp.code() + ")");
            }

            respText = rb.string();
            
            // Defensive check for empty response
            if (respText == null || respText.isEmpty()) {
                throw new IOException("WARP reg returned empty response body");
            }
        }

        Log.d(TAG, "WARP reg response received (" + respText.length() + " bytes)");

        // Parse and validate response
        WarpConfig config = parseRegistrationResponse(respText, privB64, pubB64);

        // Validate WireGuard key formats before storing
        validateWireGuardKeys(config);

        // Persist to SharedPreferences cache
        persistConfig(prefs, config);

        Log.d(TAG, "[WARP] Registered with Cloudflare: v4=" + config.v4Address + 
                " endpoint=" + config.endpoint);
        
        return config;
    }

    /**
     * Parses Cloudflare registration response JSON.
     * Validates all required fields are present and non-empty.
     */
    private static WarpConfig parseRegistrationResponse(
            String respText, String privB64, String pubB64) throws JSONException, IOException {
        
        JSONObject json = new JSONObject(respText);

        // Validate top-level structure
        if (!json.has(JSON_CONFIG)) {
            throw new IOException("WARP response missing 'config' field");
        }
        JSONObject config = json.getJSONObject(JSON_CONFIG);

        // Parse peers array
        if (!config.has(JSON_PEERS)) {
            throw new IOException("WARP config missing 'peers' field");
        }
        JSONArray peers = config.getJSONArray(JSON_PEERS);
        if (peers.length() == 0) {
            throw new IOException("WARP config 'peers' array is empty");
        }

        JSONObject peer0 = peers.getJSONObject(0);
        
        // Extract server public key
        if (!peer0.has(JSON_PUBLIC_KEY)) {
            throw new IOException("WARP peer[0] missing 'public_key' field");
        }
        String srvPub = peer0.getString(JSON_PUBLIC_KEY);
        if (srvPub == null || srvPub.isEmpty()) {
            throw new IOException("WARP server public_key is empty");
        }

        // Extract endpoint
        if (!peer0.has(JSON_ENDPOINT)) {
            throw new IOException("WARP peer[0] missing 'endpoint' field");
        }
        JSONObject ep = peer0.getJSONObject(JSON_ENDPOINT);
        if (!ep.has(JSON_HOST)) {
            throw new IOException("WARP endpoint missing 'host' field");
        }
        String epHost = ep.getString(JSON_HOST);
        if (epHost == null || epHost.isEmpty()) {
            throw new IOException("WARP endpoint host is empty");
        }

        // Parse interface addresses
        if (!config.has(JSON_INTERFACE)) {
            throw new IOException("WARP config missing 'interface' field");
        }
        JSONObject iface = config.getJSONObject(JSON_INTERFACE);

        if (!iface.has(JSON_ADDRESSES)) {
            throw new IOException("WARP interface missing 'addresses' field");
        }
        JSONObject addrs = iface.getJSONObject(JSON_ADDRESSES);

        // v4 is required
        if (!addrs.has(JSON_V4)) {
            throw new IOException("WARP addresses missing 'v4' field");
        }
        String v4 = addrs.getString(JSON_V4);
        if (v4 == null || v4.isEmpty()) {
            throw new IOException("WARP v4 address is empty");
        }

        // v6 and client_id are optional
        String v6 = addrs.optString(JSON_V6, "");
        String clientId = config.optString(JSON_CLIENT_ID, "");

        // Build config object
        WarpConfig c = new WarpConfig();
        c.privateKeyBase64 = privB64;
        c.publicKeyBase64 = pubB64;
        c.serverPublicKey = srvPub;
        c.endpoint = epHost;
        c.v4Address = v4;
        c.v6Address = v6;
        c.clientId = clientId;

        return c;
    }

    /**
     * Validates that WireGuard keys are properly formatted base64.
     * @throws IllegalStateException if keys cannot be parsed
     */
    private static void validateWireGuardKeys(WarpConfig config) throws IllegalStateException {
        try {
            Key.fromBase64(config.privateKeyBase64);
        } catch (Exception e) {
            throw new IllegalStateException(
                    "Invalid WireGuard private key format: " + e.getMessage(), e);
        }

        try {
            Key.fromBase64(config.serverPublicKey);
        } catch (Exception e) {
            throw new IllegalStateException(
                    "Invalid WireGuard server public key format: " + e.getMessage(), e);
        }
    }

    /**
     * Persists WarpConfig to SharedPreferences atomically (via single edit transaction).
     */
    private static void persistConfig(SharedPreferences prefs, WarpConfig c) {
        prefs.edit()
                .putString(K_PRIV, c.privateKeyBase64)
                .putString(K_PUB, c.publicKeyBase64)
                .putString(K_SRV_PUB, c.serverPublicKey)
                .putString(K_ENDPOINT, c.endpoint)
                .putString(K_V4, c.v4Address)
                .putString(K_V6, c.v6Address)
                .putString(K_CLIENT_ID, c.clientId)
                .apply();
    }

    /**
     * Clears all cached WARP configuration from SharedPreferences.
     * Safe to call even if cache is empty or prefs is null.
     */
    public static void clearCache(SharedPreferences prefs) {
        if (prefs == null) {
            return;
        }
        prefs.edit()
                .remove(K_PRIV).remove(K_PUB).remove(K_SRV_PUB)
                .remove(K_ENDPOINT).remove(K_V4).remove(K_V6).remove(K_CLIENT_ID)
                .apply();
    }

    /**
     * Generates ISO8601 timestamp in UTC.
     * SimpleDateFormat is created per-call to avoid thread-safety issues.
     */
    private static String iso8601Now() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }
}