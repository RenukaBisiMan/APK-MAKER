package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Handles Cloudflare WARP device registration.
 *
 * Uses the public consumer endpoint (same one wgcf and the official 1.1.1.1 app hit):
 *   POST https://api.cloudflareclient.com/v0a2405/reg
 *
 * Each call returns a fresh free-tier WARP identity (WireGuard server pubkey, endpoint,
 * client v4/v6 addresses, and a base64 client_id used as WireGuard "reserved" bytes).
 *
 * We persist the resulting config in SharedPreferences so the app reuses the same device
 * unless we explicitly request rotation (forceFreshRegistration).
 *
 * Geo-routing: MainActivity passes a GeoEndpoint override so we can steer the tunnel
 * toward a specific Cloudflare PoP (country). The registration itself is always done
 * against the global endpoint; only the WireGuard peer endpoint is swapped.
 */
public class WarpRegistration {

    private static final String TAG = "AdsViewer/WARP-REG";

    // ─── Cloudflare registration endpoint ────────────────────────────────────
    private static final String REG_URL        = "https://api.cloudflareclient.com/v0a2405/reg";
    private static final String UA             = "okhttp/3.12.1";
    private static final String CF_CLIENT_VER  = "a-6.30-3596";

    // ─── Retry policy ─────────────────────────────────────────────────────────
    private static final int  MAX_RETRIES        = 3;
    private static final long RETRY_BACKOFF_MS   = 1500L;

    // ─── HTTP timeouts ────────────────────────────────────────────────────────
    private static final int CONNECT_TIMEOUT_SEC = 15;
    private static final int READ_TIMEOUT_SEC    = 25;
    private static final int WRITE_TIMEOUT_SEC   = 15;

    // ─── SharedPreferences keys ───────────────────────────────────────────────
    private static final String K_PRIV       = "warp_priv";
    private static final String K_PUB        = "warp_pub";
    private static final String K_SRV_PUB    = "warp_srv_pub";
    private static final String K_ENDPOINT   = "warp_endpoint";
    private static final String K_V4         = "warp_v4";
    private static final String K_V6         = "warp_v6";
    private static final String K_CLIENT_ID  = "warp_client_id";
    private static final String K_INSTALL_ID = "warp_install_id";
    private static final String K_DEVICE_ID  = "warp_device_id";
    private static final String K_REG_TS     = "warp_reg_ts";
    private static final String K_COUNTRY    = "warp_country";

    // ─── Device model pool (mirrors MainActivity.DEVICE_MODELS) ──────────────
    // Kept in sync so the WireGuard "model" field matches our spoofed UA.
    private static final String[] DEVICE_MODELS = {
        "SM-S908B", "SM-S918B", "SM-A546B", "SM-G998U", "SM-N986U",
        "SM-F946B", "SM-A536E",
        "Pixel 6",  "Pixel 6 Pro", "Pixel 7", "Pixel 7 Pro",
        "Pixel 8",  "Pixel 8 Pro", "Pixel 9", "Pixel 9 Pro",
        "Redmi Note 12", "Redmi Note 13", "Redmi Note 11",
        "OnePlus 11",    "OnePlus 12",    "OnePlus 9 Pro",
        "Nokia G50",     "Nokia X20",
        "moto g stylus 5G", "motorola edge 40",
        "ASUS_AI2202",   "ASUS_I003D",
        "POCO X6 Pro",   "POCO F5",
        "realme GT 5",   "RMX3700"
    };

    // ─── Locale pool (mirrors MainActivity.LANGUAGES, India excluded) ─────────
    private static final String[] LOCALES = {
        "en_US", "en_GB", "de_DE", "fr_FR",
        "es_ES", "pt_BR", "ja_JP", "ko_KR",
        "ar_SA", "it_IT", "nl_NL", "pl_PL",
        "tr_TR", "id_ID", "ms_MY", "zh_TW"
    };

    // ─── Android version pool ─────────────────────────────────────────────────
    private static final String[] ANDROID_VERSIONS = {
        "9", "10", "11", "12", "13", "14", "15"
    };

    // =========================================================================
    // Public data class
    // =========================================================================
    public static class WarpConfig {
        public String privateKeyBase64;   // our WireGuard private key
        public String publicKeyBase64;    // our WireGuard public key
        public String serverPublicKey;    // Cloudflare's WireGuard pubkey
        public String endpoint;           // host:port (may be overridden by geo)
        public String v4Address;          // 172.16.0.x
        public String v6Address;          // 2606:…
        public String clientId;           // base64, WireGuard 'reserved' bytes
        public String installId;          // persisted install UUID
        public String deviceId;           // Cloudflare device ID from response
        public String country;            // country code this config is linked to
        public long   registeredAt;       // epoch ms of registration
    }

    // =========================================================================
    // Main entry point
    // =========================================================================

    /**
     * Returns a cached {@link WarpConfig} or registers a brand-new device with
     * Cloudflare. Re-tries up to {@value MAX_RETRIES} times with exponential back-off.
     *
     * @param prefs                  app SharedPreferences
     * @param forceFreshRegistration if {@code true} ignores cache and registers anew
     */
    public static WarpConfig getOrRegister(
            SharedPreferences prefs,
            boolean forceFreshRegistration) throws Exception {

        // ── Return cached config if valid ──────────────────────────────────────
        if (!forceFreshRegistration && isCacheValid(prefs)) {
            WarpConfig c = loadFromCache(prefs);
            Log.d(TAG, "[CACHE] Reusing registration: v4=" + c.v4Address
                    + " country=" + c.country
                    + " age=" + cacheAgeMinutes(prefs) + " min");
            return c;
        }

        Log.d(TAG, "[REG] Registering new WARP device with Cloudflare...");

        // ── Retry loop ─────────────────────────────────────────────────────────
        Exception lastError = null;
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                WarpConfig c = doRegister(prefs);
                saveToCache(prefs, c);
                Log.d(TAG, "[REG] Success on attempt " + attempt
                        + " | v4=" + c.v4Address
                        + " endpoint=" + c.endpoint
                        + " country=" + c.country);
                return c;
            } catch (Exception e) {
                lastError = e;
                Log.w(TAG, "[REG] Attempt " + attempt + "/" + MAX_RETRIES
                        + " failed: " + e.getMessage());
                if (attempt < MAX_RETRIES) {
                    Thread.sleep(RETRY_BACKOFF_MS * attempt);
                }
            }
        }

        throw new IOException("[REG] All " + MAX_RETRIES
                + " registration attempts failed", lastError);
    }

    // =========================================================================
    // Cache helpers
    // =========================================================================

    /** Returns true if all required keys are present in prefs. */
    private static boolean isCacheValid(SharedPreferences prefs) {
        return prefs.contains(K_PRIV)
                && prefs.contains(K_SRV_PUB)
                && prefs.contains(K_V4)
                && prefs.contains(K_V6)
                && prefs.contains(K_ENDPOINT);
    }

    private static WarpConfig loadFromCache(SharedPreferences prefs) {
        WarpConfig c      = new WarpConfig();
        c.privateKeyBase64 = prefs.getString(K_PRIV,       "");
        c.publicKeyBase64  = prefs.getString(K_PUB,        "");
        c.serverPublicKey  = prefs.getString(K_SRV_PUB,    "");
        c.endpoint         = prefs.getString(K_ENDPOINT,   "");
        c.v4Address        = prefs.getString(K_V4,         "");
        c.v6Address        = prefs.getString(K_V6,         "");
        c.clientId         = prefs.getString(K_CLIENT_ID,  "");
        c.installId        = prefs.getString(K_INSTALL_ID, "");
        c.deviceId         = prefs.getString(K_DEVICE_ID,  "");
        c.country          = prefs.getString(K_COUNTRY,    "US");
        c.registeredAt     = prefs.getLong(K_REG_TS,       0L);
        return c;
    }

    private static void saveToCache(SharedPreferences prefs, WarpConfig c) {
        prefs.edit()
                .putString(K_PRIV,       c.privateKeyBase64)
                .putString(K_PUB,        c.publicKeyBase64)
                .putString(K_SRV_PUB,    c.serverPublicKey)
                .putString(K_ENDPOINT,   c.endpoint)
                .putString(K_V4,         c.v4Address)
                .putString(K_V6,         c.v6Address)
                .putString(K_CLIENT_ID,  c.clientId)
                .putString(K_INSTALL_ID, c.installId)
                .putString(K_DEVICE_ID,  c.deviceId)
                .putString(K_COUNTRY,    c.country)
                .putLong  (K_REG_TS,     c.registeredAt)
                .apply();
    }

    /** Age of cached registration in minutes (0 if never set). */
    private static long cacheAgeMinutes(SharedPreferences prefs) {
        long ts = prefs.getLong(K_REG_TS, 0L);
        if (ts == 0L) return 0;
        return TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - ts);
    }

    /**
     * Wipes all cached WARP credentials.
     * Called by {@code MainActivity.advanceToNextCountry()} before re-registering.
     */
    public static void clearCache(SharedPreferences prefs) {
        prefs.edit()
                .remove(K_PRIV).remove(K_PUB).remove(K_SRV_PUB)
                .remove(K_ENDPOINT).remove(K_V4).remove(K_V6)
                .remove(K_CLIENT_ID).remove(K_INSTALL_ID)
                .remove(K_DEVICE_ID).remove(K_REG_TS).remove(K_COUNTRY)
                .apply();
        Log.d(TAG, "[CACHE] Cleared all cached WARP credentials");
    }

    // =========================================================================
    // Registration implementation
    // =========================================================================

    private static WarpConfig doRegister(SharedPreferences prefs) throws Exception {

        // ── WireGuard keypair ──────────────────────────────────────────────────
        KeyPair kp     = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64  = kp.getPublicKey().toBase64();

        // ── Stable install-ID (persisted across rotations; only reset on clearCache) ──
        String installId = prefs.getString(K_INSTALL_ID, null);
        if (installId == null || installId.isEmpty()) {
            installId = UUID.randomUUID().toString();
            prefs.edit().putString(K_INSTALL_ID, installId).apply();
            Log.d(TAG, "[REG] Generated new install_id: " + installId);
        }

        // ── Randomise device identity so each registration looks unique ────────
        String model         = randomChoice(DEVICE_MODELS);
        String locale        = randomChoice(LOCALES);
        String androidVer    = randomChoice(ANDROID_VERSIONS);
        String fcmToken      = ""; // free tier doesn't need FCM
        String tos           = iso8601Now();

        Log.d(TAG, "[REG] Registering as model=" + model
                + " locale=" + locale + " android=" + androidVer);

        // ── Build JSON body ────────────────────────────────────────────────────
        JSONObject body = new JSONObject();
        body.put("key",        pubB64);
        body.put("install_id", installId);
        body.put("fcm_token",  fcmToken);
        body.put("tos",        tos);
        body.put("model",      model);
        body.put("serial_number", UUID.randomUUID().toString());
        body.put("os_version", androidVer);
        body.put("type",       "Android");
        body.put("locale",     locale);

        // ── HTTP client ────────────────────────────────────────────────────────
        OkHttpClient http = new OkHttpClient.Builder()
                .connectTimeout(CONNECT_TIMEOUT_SEC, TimeUnit.SECONDS)
                .readTimeout   (READ_TIMEOUT_SEC,    TimeUnit.SECONDS)
                .writeTimeout  (WRITE_TIMEOUT_SEC,   TimeUnit.SECONDS)
                .build();

        Request req = new Request.Builder()
                .url(REG_URL)
                .header("User-Agent",       UA)
                .header("CF-Client-Version",CF_CLIENT_VER)
                .header("Content-Type",     "application/json; charset=utf-8")
                .header("Accept",           "application/json")
                .post(RequestBody.create(
                        body.toString(),
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        // ── Execute & parse ────────────────────────────────────────────────────
        String respText;
        int    httpCode;
        try (Response resp = http.newCall(req).execute()) {
            httpCode = resp.code();
            ResponseBody rb = resp.body();
            respText = rb != null ? rb.string() : "";
            if (!resp.isSuccessful()) {
                throw new IOException("WARP reg HTTP " + httpCode
                        + ": " + truncate(respText, 300));
            }
        }

        Log.d(TAG, "[REG] HTTP 200 – parsing response (" + respText.length() + " bytes)");

        return parseResponse(privB64, pubB64, installId, locale, respText);
    }

    // =========================================================================
    // JSON parsing
    // =========================================================================

    private static WarpConfig parseResponse(
            String privB64,
            String pubB64,
            String installId,
            String locale,
            String respText) throws Exception {

        JSONObject json   = new JSONObject(respText);
        JSONObject config = json.getJSONObject("config");

        // ── Peer / endpoint ────────────────────────────────────────────────────
        JSONArray  peers  = config.getJSONArray("peers");
        JSONObject peer0  = peers.getJSONObject(0);
        String     srvPub = peer0.getString("public_key");

        JSONObject ep     = peer0.getJSONObject("endpoint");
        // Prefer the plain "host" field; fall back to "v4" if needed
        String epHost = ep.optString("host",
                ep.optString("v4", "engage.cloudflareclient.com:2408"));

        // ── Interface addresses ────────────────────────────────────────────────
        JSONObject iface  = config.getJSONObject("interface");
        JSONObject addrs  = iface.getJSONObject("addresses");
        String v4         = addrs.getString("v4");
        String v6         = addrs.optString("v6", "");

        // ── Optional fields ────────────────────────────────────────────────────
        String clientId  = config.optString("client_id", "");
        String deviceId  = json.optString("id", "");

        // Derive country hint from locale string (e.g. "en_US" → "US")
        String country = deriveCountryFromLocale(locale);

        // ── Validate key material ──────────────────────────────────────────────
        Key.fromBase64(privB64);
        Key.fromBase64(srvPub);

        // ── Build config ───────────────────────────────────────────────────────
        WarpConfig c       = new WarpConfig();
        c.privateKeyBase64 = privB64;
        c.publicKeyBase64  = pubB64;
        c.serverPublicKey  = srvPub;
        c.endpoint         = epHost;
        c.v4Address        = v4;
        c.v6Address        = v6;
        c.clientId         = clientId;
        c.installId        = installId;
        c.deviceId         = deviceId;
        c.country          = country;
        c.registeredAt     = System.currentTimeMillis();

        Log.d(TAG, "[REG] Parsed: v4=" + v4 + " v6=" + truncate(v6, 20)
                + " srvPub=" + truncate(srvPub, 10) + "…"
                + " endpoint=" + epHost
                + " clientId=" + (clientId.isEmpty() ? "(none)" : "present")
                + " deviceId=" + truncate(deviceId, 8) + "…"
                + " country=" + country);

        return c;
    }

    // =========================================================================
    // Utility
    // =========================================================================

    /** Picks a random element from an array using {@link Math#random()}. */
    private static String randomChoice(String[] arr) {
        return arr[(int) (Math.random() * arr.length)];
    }

    /**
     * Derives a two-letter country code from a locale string such as {@code "en_US"}.
     * Falls back to {@code "US"} if the locale is malformed.
     */
    private static String deriveCountryFromLocale(String locale) {
        if (locale != null && locale.contains("_")) {
            String code = locale.split("_")[1].toUpperCase(Locale.US);
            // Exclude India (IN) – mirrors MainActivity GEO_ENDPOINTS list
            if ("IN".equals(code)) return "US";
            return code;
        }
        return "US";
    }

    /** Returns current UTC time formatted as ISO-8601 (required by Cloudflare TOS field). */
    private static String iso8601Now() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }

    /** Truncates a string for safe logging. */
    private static String truncate(String s, int max) {
        if (s == null) return "(null)";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }
}