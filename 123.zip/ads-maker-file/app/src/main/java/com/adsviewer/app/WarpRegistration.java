package com.adsviewer.app;

import android.content.SharedPreferences;
import android.util.Log;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class WarpRegistration {

    private static final String TAG = "AdsViewer/WARP-REG";

    // ─── Cloudflare WARP API endpoints (try in order) ────────────────────────
    // These are the real endpoints used by the official 1.1.1.1 app and wgcf
    private static final String[] REG_URLS = {
        "https://api.cloudflareclient.com/v0a2408/reg",  // latest
        "https://api.cloudflareclient.com/v0a2406/reg",  // fallback
        "https://api.cloudflareclient.com/v0a2405/reg",  // fallback
        "https://api.cloudflareclient.com/v0a1922/reg"   // legacy fallback
    };

    // ─── Real Cloudflare WARP WireGuard server public key ────────────────────
    // This is Cloudflare's actual published WARP server public key
    public static final String CF_SERVER_PUBLIC_KEY =
            "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h8GU=";

    // ─── Real Cloudflare WARP endpoints ──────────────────────────────────────
    // These are actual Cloudflare anycast IPs used by WARP
    public static final String[] CF_ENDPOINTS = {
        "engage.cloudflareclient.com:2408",
        "162.159.192.1:2408",
        "162.159.193.1:2408",
        "162.159.195.1:2408",
        "162.159.192.1:500",
        "162.159.193.1:500",
        "162.159.195.1:500",
        "162.159.192.1:1701",
        "162.159.193.1:1701",
        "engage.cloudflareclient.com:500"
    };

    private static final String UA            = "okhttp/3.12.1";
    private static final String CF_CLIENT_VER = "a-6.30-3596";

    // ─── Timeouts ─────────────────────────────────────────────────────────────
    private static final int CONNECT_TIMEOUT_SEC = 20;
    private static final int READ_TIMEOUT_SEC    = 30;
    private static final int WRITE_TIMEOUT_SEC   = 20;

    // ─── SharedPreferences keys ───────────────────────────────────────────────
    private static final String K_PRIV       = "warp_priv";
    private static final String K_PUB        = "warp_pub";
    private static final String K_SRV_PUB    = "warp_srv_pub";
    private static final String K_ENDPOINT   = "warp_endpoint";
    private static final String K_V4         = "warp_v4";
    private static final String K_V6         = "warp_v6";
    private static final String K_CLIENT_ID  = "warp_client_id";
    private static final String K_INSTALL_ID = "warp_install_id";
    private static final String K_DEVICE_ID  = "warp_device_id";
    private static final String K_REG_TS     = "warp_reg_ts";
    private static final String K_COUNTRY    = "warp_country";

    // ─── Device models matching MainActivity ──────────────────────────────────
    private static final String[] DEVICE_MODELS = {
        "SM-S908B", "SM-S918B", "SM-A546B", "SM-G998U",
        "Pixel 7",  "Pixel 7 Pro", "Pixel 8", "Pixel 8 Pro",
        "Redmi Note 12", "Redmi Note 13",
        "OnePlus 11", "OnePlus 12",
        "POCO X6 Pro", "POCO F5",
        "moto g stylus 5G", "motorola edge 40"
    };

    private static final String[] LOCALES = {
        "en_US", "en_GB", "de_DE", "fr_FR",
        "es_ES", "pt_BR", "ja_JP", "ko_KR",
        "ar_SA", "it_IT", "nl_NL", "pl_PL"
    };

    private static final String[] ANDROID_VERSIONS = {
        "11", "12", "13", "14", "15"
    };

    // =========================================================================
    // Public data class
    // =========================================================================
    public static class WarpConfig {
        public String privateKeyBase64;
        public String publicKeyBase64;
        public String serverPublicKey;
        public String endpoint;
        public String v4Address;
        public String v6Address;
        public String clientId;
        public String installId;
        public String deviceId;
        public String country;
        public long   registeredAt;

        @Override
        public String toString() {
            return "WarpConfig{"
                + "v4=" + v4Address
                + ", v6=" + (v6Address != null ? v6Address.substring(0, Math.min(20, v6Address.length())) : "none")
                + ", endpoint=" + endpoint
                + ", country=" + country
                + ", hasPrivKey=" + (privateKeyBase64 != null && !privateKeyBase64.isEmpty())
                + ", hasSrvKey=" + (serverPublicKey != null && !serverPublicKey.isEmpty())
                + "}";
        }
    }

    // =========================================================================
    // Main entry point
    // =========================================================================
    public static WarpConfig getOrRegister(
            SharedPreferences prefs,
            boolean forceFreshRegistration) throws Exception {

        // Return cached config if valid
        if (!forceFreshRegistration && isCacheValid(prefs)) {
            WarpConfig c = loadFromCache(prefs);
            Log.d(TAG, "[CACHE] Reusing: " + c);
            return c;
        }

        Log.d(TAG, "[REG] Starting fresh WARP registration...");

        // Try each API endpoint version
        Exception lastError = null;
        for (String regUrl : REG_URLS) {
            try {
                Log.d(TAG, "[REG] Trying endpoint: " + regUrl);
                WarpConfig c = doRegister(prefs, regUrl);
                saveToCache(prefs, c);
                Log.d(TAG, "[REG] SUCCESS: " + c);
                return c;
            } catch (Exception e) {
                lastError = e;
                Log.w(TAG, "[REG] Failed with " + regUrl + " → " + e.getMessage());
            }
        }

        // All API endpoints failed — build a minimal config using
        // known Cloudflare public key so the tunnel can still attempt connection
        Log.w(TAG, "[REG] All API endpoints failed. Trying offline key generation...");
        try {
            WarpConfig c = buildOfflineConfig(prefs);
            saveToCache(prefs, c);
            Log.w(TAG, "[REG] Using offline config: " + c);
            return c;
        } catch (Exception e2) {
            Log.e(TAG, "[REG] Offline config also failed: " + e2.getMessage());
        }

        throw new IOException("[REG] Registration completely failed. Last error: "
                + (lastError != null ? lastError.getMessage() : "unknown"));
    }

    // =========================================================================
    // Registration implementation
    // =========================================================================
    private static WarpConfig doRegister(
            SharedPreferences prefs,
            String regUrl) throws Exception {

        // WireGuard keypair
        KeyPair kp     = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64  = kp.getPublicKey().toBase64();

        // Stable install-ID
        String installId = prefs.getString(K_INSTALL_ID, null);
        if (installId == null || installId.isEmpty()) {
            installId = UUID.randomUUID().toString();
            prefs.edit().putString(K_INSTALL_ID, installId).apply();
        }

        String model      = randomChoice(DEVICE_MODELS);
        String locale     = randomChoice(LOCALES);
        String androidVer = randomChoice(ANDROID_VERSIONS);

        Log.d(TAG, "[REG] model=" + model + " locale=" + locale
                + " android=" + androidVer + " pubKey=" + pubB64.substring(0, 10) + "...");

        // Build request body
        JSONObject body = new JSONObject();
        body.put("key",           pubB64);
        body.put("install_id",    installId);
        body.put("fcm_token",     "");
        body.put("tos",           iso8601Now());
        body.put("model",         model);
        body.put("serial_number", UUID.randomUUID().toString());
        body.put("os_version",    androidVer);
        body.put("type",          "Android");
        body.put("locale",        locale);

        Log.d(TAG, "[REG] Request body: " + body);

        OkHttpClient http = new OkHttpClient.Builder()
                .connectTimeout(CONNECT_TIMEOUT_SEC, TimeUnit.SECONDS)
                .readTimeout   (READ_TIMEOUT_SEC,    TimeUnit.SECONDS)
                .writeTimeout  (WRITE_TIMEOUT_SEC,   TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        Request req = new Request.Builder()
                .url(regUrl)
                .header("User-Agent",        UA)
                .header("CF-Client-Version", CF_CLIENT_VER)
                .header("Content-Type",      "application/json; charset=utf-8")
                .header("Accept",            "application/json")
                .post(RequestBody.create(
                        body.toString(),
                        MediaType.parse("application/json; charset=utf-8")))
                .build();

        String respText;
        int    httpCode;
        try (Response resp = http.newCall(req).execute()) {
            httpCode = resp.code();
            ResponseBody rb = resp.body();
            respText = rb != null ? rb.string() : "";

            Log.d(TAG, "[REG] HTTP " + httpCode + " body=" + truncate(respText, 500));

            if (!resp.isSuccessful()) {
                throw new IOException("HTTP " + httpCode + ": " + truncate(respText, 200));
            }
        }

        return parseResponse(privB64, pubB64, installId, locale, respText);
    }

    // =========================================================================
    // Offline fallback: known Cloudflare server key + local WG keypair
    // =========================================================================
    private static WarpConfig buildOfflineConfig(SharedPreferences prefs) throws Exception {
        Log.w(TAG, "[OFFLINE] Building config with known Cloudflare public key");

        KeyPair kp     = new KeyPair();
        String privB64 = kp.getPrivateKey().toBase64();
        String pubB64  = kp.getPublicKey().toBase64();

        String installId = prefs.getString(K_INSTALL_ID, UUID.randomUUID().toString());

        // Pick a random known endpoint
        String endpoint = randomChoice(CF_ENDPOINTS);

        WarpConfig c       = new WarpConfig();
        c.privateKeyBase64 = privB64;
        c.publicKeyBase64  = pubB64;
        // Use Cloudflare's known public key directly
        c.serverPublicKey  = CF_SERVER_PUBLIC_KEY;
        c.endpoint         = endpoint;
        // WARP always assigns from this range for free tier
        c.v4Address        = "172.16.0." + (2 + (int)(Math.random() * 250));
        c.v6Address        = "2606:4700:110:8949:fed8:da60:cc3e:" + Integer.toHexString((int)(Math.random() * 65535));
        c.clientId         = "";
        c.installId        = installId;
        c.deviceId         = UUID.randomUUID().toString();
        c.country          = "US";
        c.registeredAt     = System.currentTimeMillis();

        // Validate key material
        Key.fromBase64(privB64);
        Key.fromBase64(CF_SERVER_PUBLIC_KEY);

        Log.w(TAG, "[OFFLINE] Config: v4=" + c.v4Address + " endpoint=" + c.endpoint);
        return c;
    }

    // =========================================================================
    // JSON parsing — defensive, handles multiple response formats
    // =========================================================================
    private static WarpConfig parseResponse(
            String privB64,
            String pubB64,
            String installId,
            String locale,
            String respText) throws Exception {

        Log.d(TAG, "[PARSE] Parsing registration response...");

        JSONObject json = new JSONObject(respText);

        // ── Server public key ──────────────────────────────────────────────────
        // Try multiple known locations in the response
        String srvPub = null;

        // Location 1: config.peers[0].public_key
        if (json.has("config")) {
            JSONObject config = json.getJSONObject("config");
            if (config.has("peers")) {
                JSONArray peers = config.getJSONArray("peers");
                if (peers.length() > 0) {
                    JSONObject peer0 = peers.getJSONObject(0);
                    srvPub = peer0.optString("public_key", null);
                    Log.d(TAG, "[PARSE] Found srvPub in config.peers[0]: "
                            + (srvPub != null ? srvPub.substring(0, 10) + "..." : "null"));
                }
            }
        }

        // Location 2: top-level peer_public_key
        if (srvPub == null || srvPub.isEmpty()) {
            srvPub = json.optString("peer_public_key", null);
            Log.d(TAG, "[PARSE] Found srvPub at top level: " + srvPub);
        }

        // Fallback: use known Cloudflare WARP public key
        if (srvPub == null || srvPub.isEmpty()) {
            srvPub = CF_SERVER_PUBLIC_KEY;
            Log.w(TAG, "[PARSE] Using known CF public key as fallback");
        }

        // ── Endpoint ───────────────────────────────────────────────────────────
        String epHost = null;

        if (json.has("config")) {
            JSONObject config = json.getJSONObject("config");
            if (config.has("peers")) {
                JSONArray peers = config.getJSONArray("peers");
                if (peers.length() > 0) {
                    JSONObject peer0 = peers.getJSONObject(0);
                    if (peer0.has("endpoint")) {
                        JSONObject ep = peer0.getJSONObject("endpoint");
                        epHost = ep.optString("host", null);
                        if (epHost == null) epHost = ep.optString("v4", null);
                        Log.d(TAG, "[PARSE] Found endpoint: " + epHost);
                    }
                }
            }
        }

        if (epHost == null || epHost.isEmpty()) {
            epHost = "engage.cloudflareclient.com:2408";
            Log.w(TAG, "[PARSE] Using default endpoint: " + epHost);
        }

        // ── Interface addresses ────────────────────────────────────────────────
        String v4 = null;
        String v6 = null;

        if (json.has("config")) {
            JSONObject config = json.getJSONObject("config");
            if (config.has("interface")) {
                JSONObject iface = config.getJSONObject("interface");
                if (iface.has("addresses")) {
                    JSONObject addrs = iface.getJSONObject("addresses");
                    v4 = addrs.optString("v4", null);
                    v6 = addrs.optString("v6", null);
                    Log.d(TAG, "[PARSE] Addresses: v4=" + v4
                            + " v6=" + (v6 != null ? truncate(v6, 20) : "none"));
                }
            }
        }

        // Fallback addresses
        if (v4 == null || v4.isEmpty()) {
            v4 = "172.16.0." + (2 + (int)(Math.random() * 250));
            Log.w(TAG, "[PARSE] Using fallback v4: " + v4);
        }
        if (v6 == null || v6.isEmpty()) {
            v6 = "2606:4700:110:8949:fed8:da60:cc3e:"
                    + Integer.toHexString((int)(Math.random() * 65535));
            Log.w(TAG, "[PARSE] Using fallback v6: " + v6);
        }

        // ── Optional fields ────────────────────────────────────────────────────
        String clientId = "";
        if (json.has("config")) {
            clientId = json.getJSONObject("config").optString("client_id", "");
        }
        String deviceId = json.optString("id", UUID.randomUUID().toString());
        String country  = deriveCountryFromLocale(locale);

        // ── Validate keys ──────────────────────────────────────────────────────
        try {
            Key.fromBase64(privB64);
        } catch (Exception e) {
            throw new IOException("Invalid private key generated: " + e.getMessage());
        }
        try {
            Key.fromBase64(srvPub);
        } catch (Exception e) {
            Log.w(TAG, "[PARSE] Server pubkey validation failed, using CF fallback key");
            srvPub = CF_SERVER_PUBLIC_KEY;
        }

        // ── Build result ───────────────────────────────────────────────────────
        WarpConfig c       = new WarpConfig();
        c.privateKeyBase64 = privB64;
        c.publicKeyBase64  = pubB64;
        c.serverPublicKey  = srvPub;
        c.endpoint         = epHost;
        c.v4Address        = v4;
        c.v6Address        = v6;
        c.clientId         = clientId;
        c.installId        = installId;
        c.deviceId         = deviceId;
        c.country          = country;
        c.registeredAt     = System.currentTimeMillis();

        Log.d(TAG, "[PARSE] Complete: " + c);
        return c;
    }

    // =========================================================================
    // Cache helpers
    // =========================================================================
    private static boolean isCacheValid(SharedPreferences prefs) {
        boolean valid = prefs.contains(K_PRIV)
                && prefs.contains(K_SRV_PUB)
                && prefs.contains(K_V4)
                && prefs.contains(K_ENDPOINT);

        if (valid) {
            // Also check values are non-empty
            String priv = prefs.getString(K_PRIV, "");
            String srv  = prefs.getString(K_SRV_PUB, "");
            String v4   = prefs.getString(K_V4, "");
            valid = !priv.isEmpty() && !srv.isEmpty() && !v4.isEmpty();
        }

        Log.d(TAG, "[CACHE] Valid=" + valid);
        return valid;
    }

    private static WarpConfig loadFromCache(SharedPreferences prefs) {
        WarpConfig c       = new WarpConfig();
        c.privateKeyBase64 = prefs.getString(K_PRIV,       "");
        c.publicKeyBase64  = prefs.getString(K_PUB,        "");
        c.serverPublicKey  = prefs.getString(K_SRV_PUB,    "");
        c.endpoint         = prefs.getString(K_ENDPOINT,   "");
        c.v4Address        = prefs.getString(K_V4,         "");
        c.v6Address        = prefs.getString(K_V6,         "");
        c.clientId         = prefs.getString(K_CLIENT_ID,  "");
        c.installId        = prefs.getString(K_INSTALL_ID, "");
        c.deviceId         = prefs.getString(K_DEVICE_ID,  "");
        c.country          = prefs.getString(K_COUNTRY,    "US");
        c.registeredAt     = prefs.getLong  (K_REG_TS,     0L);
        return c;
    }

    private static void saveToCache(SharedPreferences prefs, WarpConfig c) {
        prefs.edit()
                .putString(K_PRIV,       c.privateKeyBase64)
                .putString(K_PUB,        c.publicKeyBase64)
                .putString(K_SRV_PUB,    c.serverPublicKey)
                .putString(K_ENDPOINT,   c.endpoint)
                .putString(K_V4,         c.v4Address)
                .putString(K_V6,         c.v6Address != null ? c.v6Address : "")
                .putString(K_CLIENT_ID,  c.clientId  != null ? c.clientId  : "")
                .putString(K_INSTALL_ID, c.installId != null ? c.installId : "")
                .putString(K_DEVICE_ID,  c.deviceId  != null ? c.deviceId  : "")
                .putString(K_COUNTRY,    c.country   != null ? c.country   : "US")
                .putLong  (K_REG_TS,     c.registeredAt)
                .apply();
        Log.d(TAG, "[CACHE] Saved: " + c);
    }

    public static void clearCache(SharedPreferences prefs) {
        prefs.edit()
                .remove(K_PRIV).remove(K_PUB).remove(K_SRV_PUB)
                .remove(K_ENDPOINT).remove(K_V4).remove(K_V6)
                .remove(K_CLIENT_ID).remove(K_INSTALL_ID)
                .remove(K_DEVICE_ID).remove(K_REG_TS).remove(K_COUNTRY)
                .apply();
        Log.d(TAG, "[CACHE] Cleared all credentials");
    }

    // =========================================================================
    // Utility
    // =========================================================================
    private static String randomChoice(String[] arr) {
        return arr[(int) (Math.random() * arr.length)];
    }

    private static String deriveCountryFromLocale(String locale) {
        if (locale != null && locale.contains("_")) {
            String code = locale.split("_")[1].toUpperCase(Locale.US);
            if ("IN".equals(code)) return "US"; // exclude India
            return code;
        }
        return "US";
    }

    private static String iso8601Now() {
        SimpleDateFormat df =
                new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        return df.format(new Date());
    }

    private static String truncate(String s, int max) {
        if (s == null) return "(null)";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }
}